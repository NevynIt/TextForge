# TextForge Rebuild Whitepaper

**Version:** 15d  
**Purpose:** Standalone architecture blueprint for rebuilding TextForge from scratch as a React-based, local-first, text-first, secure browser workbench. The design centers on an application-private virtual workspace, ITM as the canonical structural model, explicit pipelines, restricted Lua automation, binary workspace resources, Markdown/report generation, enterprise architecture and ArchiMate support, browser-envelope accreditation, and a Surface-based UI where editors, rich editors, structured editors, viewers, consoles, inspectors, and generated previews are peers.

This document is self-contained and states the target architecture directly. It does not own the authoritative implementation phase order, phase scopes, or current execution status; those live in the companion V15d roadmap documents under `roadmap/`.

---

## 1. Executive summary

TextForge should be rebuilt as a **React-based, local-first, text-first structured-text workbench**. Its central promise is that plain text remains the canonical source while diagrams, graphs, rendered Markdown, BPMN views, enterprise architecture views, ArchiMate views, SVGs, PNGs, images, reference PDFs, tables, reports, and transformed outputs remain derived, inspectable, and disposable artifacts. The UI should be a workbench of interchangeable surfaces, not a CodeMirror-only editor with secondary popup viewers. Editing must remain source-first: richer visual and structured editors are valuable, but only when they have an explicit and testable write-back contract to the canonical text, model, XML, CSV, or workspace resource they edit.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


The rebuild should not start as a generic web IDE. It should start as a deterministic local document workbench with four pillars:

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


1. **A virtual workspace** backed by IndexedDB, with explicit manual upload/download as the only file boundary.
2. **A canonical ITM object model** used as the internal structural representation for trees, graphs, diagrams, views, report fragments, and model-driven transformations.
3. **A pipeline-based contribution architecture** where trusted internal TypeScript contributions parse, transform, render, validate, and export content.
4. **A restricted Lua automation layer** for user-defined transformations and actions, replacing unsafe user-provided JavaScript plugins.
5. **A reusable browser-envelope accreditation profile** that demonstrates TextForge is packaged with the expected browser safeguards: no unapproved network egress, no remote code loading, no privileged local filesystem APIs, no broad extension permissions, and no unsafe service-worker escape path.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


The recommended rebuild should use React as the UI foundation and reuse proven libraries where they do not compromise the product model:

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


| Area | Selected component |
|---|---|
| UI runtime | React 19.x + TypeScript |
| Workbench surface model | custom SurfaceRegistry, SurfaceSessionManager, and PlacementManager |
| Build tool | Vite React TypeScript app |
| Source editor | CodeMirror 6 |
| Editable surface model | custom SurfaceContribution capabilities including source, rich, table, diagram, model, console, and controlled write-back surfaces |
| Rich Markdown editor | Milkdown as preferred open-source candidate, introduced only after round-trip tests; MDXEditor only after dependency audit |
| Semantic table/matrix editing | TanStack Table by default; AG Grid Community only if spreadsheet-like UX is needed and Enterprise packages are excluded |
| Controlled graph/diagram editing | React Flow for later pipeline, flowchart, and small graph editing with explicit patch generation |
| Sketch/annotation resources | Excalidraw for open-source baseline sketch and annotation surfaces |
| Workspace tree UI | React Arborist |
| IndexedDB persistence | Dexie.js |
| Read-only image resources | native browser image rendering through workspace blob URLs |
| Read-only PDF resources | PDF.js or browser-native PDF embed, with PDF.js preferred for consistent local viewing |
| Zip import/export | fflate |
| Markdown preview | markdown-it |
| Markdown/report AST pipeline | unified / remark / rehype |
| Markdown local asset resolution | workspace asset resolver producing scoped blob URLs |
| Mermaid diagrams | Mermaid |
| Graphviz rendering | Viz.js or equivalent local Graphviz WASM |
| SVG to PNG export | browser canvas rasterization, with canvg considered only if native SVG image rasterization is insufficient |
| Graph viewer | Cytoscape.js |
| Large graph viewer | Sigma.js + Graphology |
| Mind map viewer | jsMind |
| BPMN viewer/modeler | bpmn-js + bpmn-moddle, with visible-attribution/license acceptance and controlled XML write-back |
| Enterprise architecture / ArchiMate | ITM ArchiMate profiles, ArchiMate exchange XML import/export transformers, and generated graph/SVG/matrix surfaces |
| Future visual graph editing | React Flow, behind controlled write-back only |
| Lua runtime | Fengari |
| Lua console | xterm.js, optional but aligned with the intended product direction |
| Popovers/menus | Floating UI, with Radix UI/shadcn-style primitives where useful |
| Main/popup surface hosting | custom SurfaceHost components |
| Panels/layout | react-resizable-panels, initially constrained to simple shell panels |
| Drag/drop outside tree | dnd-kit, introduced when tabbed surfaces arrive |
| Tabular inspectors and editors | TanStack Table where semantic table state is needed; AG Grid Community as an optional spreadsheet-like editor |
| App state | Zustand or small custom stores, not Redux by default |
| PDF generation from Markdown HTML | late-stage browser-local export path; start with print-optimized HTML and evaluate client-side PDF generation only after core report pipeline is stable |
| Accreditation harness | reusable scripts checking CSP, manifests, service workers, remote assets, and forbidden browser APIs |

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


The key custom components should be: virtual workspace model, ITM integration, pipeline runner, diagnostics model, source/view bridge, report generation orchestration, Lua sandbox policy, controlled write-back, and a reusable browser-envelope accreditation configuration/harness.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


---

## 2. Product doctrine

The rebuild should preserve the following invariants.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


```text
1. Text is canonical.
2. The workspace is virtual and local.
3. ITM is the canonical structural object model.
4. Viewers are projections, not source owners.
5. Pipelines are explicit, traceable, and diagnosable.
6. User automation is Lua, not JavaScript.
7. No network, no server, no telemetry, no silent filesystem access in the accredited local profile.
8. Diagnostics are universal and first-class.
9. Source/view links are first-class.
10. Reports are generated from Markdown + ITM, not hand-maintained derived artifacts.
11. Enterprise architecture and ArchiMate are profile-driven model workflows over ITM, not separate opaque diagram stores.
12. Binary resources are workspace assets: viewable and referenceable, but not silently linked to the local filesystem.
13. Editors and viewers are both surfaces; placement is independent from capability.
14. Rich, visual, and structured editors are subordinate to canonical source resources.
15. No non-source editor is accepted without a declared write-back contract, unsupported-construct policy, round-trip tests, and source-editor fallback.
16. Dependencies must remain compatible with an open-source TextForge distribution.
```

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


These invariants should be treated as architectural tests. A new feature that violates one of them should be rejected or redesigned.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.



---

## 3. System context

TextForge is intended to run as:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


1. a local/static web app where feasible;
2. a packaged browser extension;
3. optionally, a PWA-like local web app if served from a controlled origin.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


All accredited local targets must preserve the same security claim:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


> TextForge cannot silently access or modify user-visible local files. Local files, including images and reference PDFs, enter through explicit user upload/import or ZIP import. Local files leave through explicit user download/export, ZIP export, copy, or print. The accredited local profile performs no unapproved network access and loads no remote code, remote plugins, or CDN assets.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


This is stronger than “offline-capable.” It is a deliberate accreditation posture.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


The security claim should be understood as a **browser-envelope claim**, not a proof of every internal implementation detail. The accreditation harness should verify that the browser and deployment safeguards are present and correctly configured. The browser then enforces the core boundary through CSP, extension permissions, service-worker restrictions, same-origin packaging, and the absence of privileged filesystem APIs.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


TextForge-specific architectural discipline remains important, but it should not be confused with reusable accreditation. For example, TextForge should still use a `WorkspaceStorageGateway`, `FileGateway`, and `ExportGateway` because they make the code easier to reason about. However, the reusable accreditation harness should not attempt to prove that only those gateway modules ever touch IndexedDB or user-mediated file input. IndexedDB and ordinary file input are allowed browser capabilities inside the app. The accreditation boundary is about preventing unapproved network egress, remote code loading, broad extension permissions, service-worker escape paths, and privileged silent filesystem access.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


### 3.1 Browser-envelope accreditation profile

The default TextForge target should conform to a reusable profile similar to:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


```yaml
profile: local-only-manual-file-workspace-webapp
network:
  mode: none
remoteCode:
  scripts: forbidden
  plugins: forbidden
  cdnRuntimeAssets: forbidden
localFiles:
  silentRead: forbidden
  silentWrite: forbidden
  fileSystemAccessApi: forbidden
  directoryHandles: forbidden
  persistentFileHandles: forbidden
  manualFileInput: allowed
  manualDownloadExport: allowed
  zipImportExport: allowed
workspace:
  applicationPrivateWorkspace: allowed
  persistence: indexedDB
  liveLocalDirectoryMirror: forbidden
extension:
  broadHostPermissions: forbidden
  fileAccess: forbidden
  nativeMessaging: forbidden
pwa:
  serviceWorkerArbitraryProxy: forbidden
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


This profile is intentionally application-independent. It can apply to TextForge, another local Markdown tool, a PDF utility, a modelling workbench, or a browser-based document processor.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


### 3.2 What the accreditation harness should verify

The reusable harness should check the deployment envelope:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


- CSP for the static/PWA target;
- extension manifest permissions for the extension target;
- PWA manifest and service-worker pattern for the PWA target;
- final built HTML and bundles for remote scripts, remote workers, remote imports, CDN assets, and external origins;
- final artifacts for forbidden privileged local filesystem APIs such as `showOpenFilePicker`, `showSaveFilePicker`, `showDirectoryPicker`, `FileSystemFileHandle`, and `FileSystemDirectoryHandle`;
- absence of broad extension permissions such as `<all_urls>`, `file://` access, or `nativeMessaging`;
- no service-worker code that acts as an arbitrary network proxy;
- no runtime network policy that contradicts the declared profile.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


The harness should not become a TextForge architecture verifier. It should not need to know the TextForge workspace model, ITM processor, viewer registry, Lua module layout, or whether all storage writes pass through a particular class. Those checks can exist as ordinary project tests, but they are not the reusable accreditation core.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


### 3.3 Internal architecture rules versus accreditation rules

The distinction should be explicit:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


| Concern | Belongs to | Example |
|---|---|---|
| Browser-enforced no-network posture | Accreditation harness | CSP `connect-src 'none'`, no external origins, no WebSocket to remote host |
| No privileged local filesystem authority | Accreditation harness | no File System Access API, no directory handles, no extension `file://` access |
| No remote code loading | Accreditation harness | no remote scripts, workers, modules, or CDN runtime dependencies |
| Workspace maintainability | TextForge architecture | use `WorkspaceManager` and Dexie consistently |
| Gateway discipline | TextForge architecture | route imports through `FileGateway` for clarity |
| ITM correctness | TextForge tests | parser/resolver/serializer tests |
| Lua API quality | TextForge tests | capability tests for `tf.*` APIs |

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


This keeps the accreditation harness reusable across applications and prevents it from becoming an overfitted static-analysis project.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


---

## 4. Target architecture overview

The Surface model changes the center of gravity of the runtime architecture. The application should not be built around the assumption that the main pane is always CodeMirror and that every viewer is a popup. Instead, TextForge should be built around a **Surface Workbench**.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`.


A **surface** is any interactive or read-only work area that can be hosted by the application shell. CodeMirror is one surface. A Markdown preview is another. An image viewer, PDF viewer, ITM graph, BPMN diagram, Lua console, diagnostics table, and generated report preview are also surfaces.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`.


Placement is separate from identity:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`.


```text
Resource or pipeline output -> Surface contribution -> Surface session -> Placement
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`.


Initial placements should be deliberately simple:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`.


```text
Stage 1 target:
  one main surface area
  optional popup placement for any surface that supports it

Phase 3.1 usability recovery:
  narrow main-session document tab strip
  cleaner React shell

Stage 2 target, later:
  advanced tabbed main surface groups
  editors and viewers as peer tabs

Future after Stage 2:
  split panes
  saved layouts
  detached browser windows
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`.


### 4.1 Runtime architecture

```mermaid
flowchart TD
  User[User]
  Shell[Application Shell]
  Workspace[Virtual Workspace Manager]
  Store[(IndexedDB via Dexie)]
  SurfaceRegistry[Surface Registry]
  SurfaceSessions[Surface Session Manager]
  Placement[Placement Manager]
  MainHost[Main Surface Host]
  PopupHost[Popup Surface Host]
  Pipelines[Pipeline Runner]
  Plugins[Trusted TS Contribution Registry]
  Lua[Lua Worker Sandbox]
  ITM[ITM Processor]
  Markdown[Markdown / Report Engine]
  Assets[Binary Resource / Asset Service]
  Diagnostics[Diagnostics Service]
  Export[Manual Export / Zip / File Download]
  Build[Build Outputs static / extension / PWA]
  Harness[Reusable Accreditation Harness browser envelope checks]

  User --> Shell
  Shell --> Workspace
  Workspace --> Store
  Workspace --> Assets
  Shell --> SurfaceRegistry
  Shell --> SurfaceSessions
  SurfaceSessions --> Placement
  Placement --> MainHost
  Placement --> PopupHost
  SurfaceRegistry --> MainHost
  SurfaceRegistry --> PopupHost
  MainHost --> Pipelines
  PopupHost --> Pipelines
  Pipelines --> Plugins
  Pipelines --> Lua
  Pipelines --> ITM
  Pipelines --> Markdown
  Pipelines --> Assets
  Plugins --> Diagnostics
  Lua --> Diagnostics
  ITM --> Diagnostics
  Markdown --> Diagnostics
  Assets --> Diagnostics
  SurfaceRegistry --> Diagnostics
  Shell --> Export
  Shell --> Build
  Build --> Harness
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


The accreditation harness is intentionally shown outside the runtime application. It verifies the packaging and browser security envelope. It is not an internal runtime service and should not be coupled to TextForge-specific domain modules.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


### 4.2 Source, model, surface, and export

The important separation is now between **source**, **model**, **surface**, **placement**, and **export**.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


```mermaid
flowchart LR
  Source[Workspace resource or text source]
  Parse[Parsers / transformers]
  Model[Canonical model.itm / typed values]
  Project[Surface-specific projection]
  Surface[Surface instance]
  Placement[Main or popup placement]
  Export[Derived exports / generated workspace assets]

  Source --> Parse
  Parse --> Model
  Model --> Project
  Project --> Surface
  Surface --> Placement
  Surface --> Export

  Surface -.controlled write-back patch.-> Source
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


This keeps the text/model source-of-truth doctrine intact while allowing rendered artifacts to become first-class work surfaces.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


### 4.3 Resource surfaces and derived surfaces

Two surface classes should be distinguished.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


**Resource surfaces** open a workspace resource directly:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


```text
.itm      -> CodeMirror editor / ITM tree / ITM graph / ITM inspector
.md       -> CodeMirror editor / Markdown preview / report preview
.svg      -> SVG viewer / CodeMirror XML source view
.png      -> image viewer
.pdf      -> read-only PDF viewer
.lua      -> CodeMirror editor / Lua runner / Lua console
.bpmn     -> CodeMirror XML editor / BPMN viewer
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


**Derived surfaces** are generated from a source resource or a pipeline:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


```text
Markdown rendered HTML
ITM dependency graph
Mermaid rendered SVG
Graphviz rendered SVG
Report preview
Diagnostics summary
Generated PNG preview
Generated SVG preview
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


Derived surfaces must carry provenance: source resources, source versions, pipeline ID, generated asset ID if any, and stale/current state.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


---

## 5. Selected reusable components and rationale

### 5.1 React 19 and Vite as the UI foundation

**Decision:** Use React 19.x with TypeScript and Vite.

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


- compatibility and coding-agent support matter more than minimum bundle size;
- React is the default target for most reusable UI components and examples;
- React Arborist, React Flow, react-resizable-panels, dnd-kit, TanStack Table, Radix/shadcn-style primitives, and many testing examples are React-first;
- the app is local-first, so a moderately larger bundle is acceptable if runtime behavior remains offline and auditable.

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


**Non-goal:** Do not adopt server-first React patterns. TextForge should remain a static browser application. React Server Components, Next.js server routes, telemetry, hosted services, and runtime network dependencies are out of scope for the accredited local build.

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


Recommended baseline:

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


```text
React 19.x
TypeScript
Vite React TypeScript template
Vitest
Playwright
ESLint
Prettier or equivalent formatting
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.



### 5.2 Surface workbench architecture

**Decision:** Introduce a custom Surface abstraction rather than treating CodeMirror as the only main work area and viewers as popup-only components.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


- TextForge is a workbench over mixed resources, not only a text editor.
- Read-only images, reference PDFs, rendered reports, ITM graphs, BPMN diagrams, and generated SVG/PNG previews often deserve to be the main surface.
- Editors and viewers should share window chrome, provenance, stale-state, source navigation, export, refresh, and placement controls.
- A common Surface interface makes future tabbed and split-pane layouts possible without rewriting every viewer.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


Recommended initial target:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


```text
Stage 1: one main surface + optional popup placement
Phase 3.1 usability recovery: narrow main-session document tab strip and cleaner React shell
Stage 2: advanced tabbed main surface groups, added later in the roadmap
Future: split panes, saved layouts, detached windows
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Use custom TextForge types for `SurfaceContribution`, `SurfaceSession`, `SurfacePlacement`, and `SurfaceCapability`. Do not over-adopt a complete IDE layout framework early.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


### 5.3 Editable surfaces and controlled write-back

**Decision:** Treat editors as Surface contributions with editing capabilities, not as a separate UI class that bypasses the workbench model.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 10, Phase 14, and Phase 15, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/bpmn`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


A surface may be read-only, source-editing, rich-text-editing, table-editing, diagram-editing, model-editing, annotation-editing, or hybrid. Placement remains independent: an editor can appear in the main surface, a popup, and later a tab.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 10, Phase 14, and Phase 15, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/bpmn`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


The critical rule is that every non-source editor must declare its write-back contract before it is accepted into TextForge. The contract must identify:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 10, Phase 14, and Phase 15, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/bpmn`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


- the canonical resource format it edits;
- the operations it supports;
- constructs it cannot preserve;
- how edits are represented as a patch or regenerated canonical source;
- the fallback source editor;
- the required round-trip tests.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 10, Phase 14, and Phase 15, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/bpmn`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


This protects the spirit of TextForge: visual convenience is allowed, but canonical text and explicit resources remain the authority.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 10, Phase 14, and Phase 15, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/bpmn`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


Recommended contribution shape:

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor; Phase 14 — Rich Markdown editing, optional and round-trip gated; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/bpmn`, `@textforge/editors`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


```ts
export interface EditableSurfaceContribution<TInput = SurfaceInput>
  extends SurfaceContribution<TInput> {
  editKind:
    | "source"
    | "rich-markdown"
    | "table"
    | "diagram"
    | "model"
    | "annotation"
    | "hybrid";

  canonicalFormat:
    | "text"
    | "markdown"
    | "itm"
    | "bpmn-xml"
    | "archimate-exchange-xml"
    | "csv"
    | "tsv"
    | "json"
    | "xml"
    | "svg"
    | "workspace-resource";

  supportedOperations: string[];
  unsupportedConstructPolicy: "preserve" | "diagnose" | "block" | "lossy-with-confirmation";
  sourceFallbackSurfaceId: string;

  previewPatch?(session: SurfaceSession): Promise<CanonicalPatch>;
  applyPatch?(session: SurfaceSession): Promise<WorkspaceUpdate>;
  getRoundTripTestSpec?(): RoundTripTestSpec;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor; Phase 14 — Rich Markdown editing, optional and round-trip gated; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/bpmn`, `@textforge/editors`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


The initial implementation should not attempt to deliver all rich and visual editors. It should make CodeMirror universal, add mature standalone editors where they are isolated and valuable, and defer more fragile rich/visual editing until the text pipeline foundation is solid.

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor; Phase 14 — Rich Markdown editing, optional and round-trip gated; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/bpmn`, `@textforge/editors`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.


### 5.4 Editor library selection and maturity posture

TextForge should prefer mature, open-source-compatible editor libraries that either preserve source directly or expose a controlled data model suitable for patch generation.

**Reverse traceability:** Implemented wholly or in part by Phase 11, Phase 14, Phase 15, Phase 16, and Phase 17, through `@textforge/tables`, `@textforge/bpmn`, `@textforge/editors`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`, `@textforge/security-profile`, `@textforge/archimate`, `@textforge/assets`.


| Editing need | Selected approach | Maturity / licensing posture | Roadmap posture |
|---|---|---|---|
| Source editing for all text formats | CodeMirror 6 | Mature, MIT | Foundational and early |
| BPMN visual editing | bpmn-js modeler | Mature domain library, custom bpmn.io license requiring visible attribution | Early standalone visual editor, with explicit XML write-back |
| Semantic tables and matrices | TanStack Table | Mature, open-source-compatible, headless | Medium-term; preferred for model catalogues and matrices |
| Spreadsheet-like grid editing | AG Grid Community | MIT Community edition; Enterprise packages excluded | Optional medium-term if richer grid UX is needed |
| Generic graph/pipeline editing | React Flow | Mature, MIT | Later; controlled patch-based graph editing |
| Rich Markdown editing | Milkdown preferred; MDXEditor only after dependency audit | Milkdown is open-source-compatible; MDXEditor must be audited | Later; optional and round-trip gated |
| Sketch and annotation resources | Excalidraw | MIT | Later; standalone workspace resource editor |
| ArchiMate visual editing | archimate-js investigation; React Flow fallback | MIT candidate but lower maturity than bpmn-js | Late investigation after EA model foundation |
| PDF viewing | PDF.js | Mature, Apache-2.0 | Early read-only resource surface |
| PDF annotation/editing | PDF.js plus custom annotation layer | Custom late-stage work | Late |
| SVG editing | CodeMirror source editor first; full visual SVG editing deferred | Avoids scope explosion | Source-first only initially |

**Reverse traceability:** Implemented wholly or in part by Phase 11, Phase 14, Phase 15, Phase 16, and Phase 17, through `@textforge/tables`, `@textforge/bpmn`, `@textforge/editors`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`, `@textforge/security-profile`, `@textforge/archimate`, `@textforge/assets`.


Libraries that are not open-source-compatible, require commercial production keys, or impose non-commercial/source-available-only terms should not enter the default TextForge baseline.

**Reverse traceability:** Implemented wholly or in part by Phase 11, Phase 14, Phase 15, Phase 16, and Phase 17, through `@textforge/tables`, `@textforge/bpmn`, `@textforge/editors`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`, `@textforge/security-profile`, `@textforge/archimate`, `@textforge/assets`.


### 5.5 Open-source dependency licensing gate

TextForge should include a dependency policy from the beginning. The policy should be used for all editor, viewer, pipeline, and UI dependencies.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


Allowed by default:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


```text
MIT
BSD-2-Clause
BSD-3-Clause
Apache-2.0
ISC
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


Allowed only with explicit review:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


```text
MPL-2.0
LGPL
custom attribution licenses, such as the bpmn.io license
licenses with branding or notice requirements
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


Rejected by default:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


```text
commercial-only
non-commercial-only
production-license-key required
source-available but non-OSI
licenses that prevent normal open-source redistribution
copyleft dependencies that unexpectedly constrain the whole TextForge distribution
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


Practical baseline decisions:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


- use TanStack Table and possibly AG Grid Community instead of Handsontable;
- use Excalidraw instead of tldraw for the open-source baseline;
- use Milkdown before MDXEditor unless MDXEditor and its dependency tree pass audit;
- accept bpmn-js only if TextForge is comfortable preserving required visible attribution;
- audit ArchiMate visual editing dependencies before selecting them as baseline.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 16 — ArchiMate visual editing investigation; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/archimate`.


### 5.6 CodeMirror 6 for editing

**Decision:** Preserve CodeMirror 6.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 2 — Source-editor coverage and language foundation, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 2 — Source-editor coverage and language foundation, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`.


- modular extension model;
- good fit for custom languages and DSLs;
- supports linting, folding, decorations, diagnostics, and source ranges;
- lighter and more composable than Monaco;
- already aligned with TextForge’s text-first model.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 2 — Source-editor coverage and language foundation, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`.


**Do not use Monaco by default.** Monaco is excellent for a browser IDE, but TextForge is not primarily a clone of VS Code. It is a structured-text workbench with custom model and viewer pipelines.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 2 — Source-editor coverage and language foundation, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`.


### 5.7 React Arborist for workspace explorer

**Decision:** Use React Arborist as the virtual workspace tree UI.

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `@textforge/ui`, `@textforge/workspace`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `@textforge/ui`, `@textforge/workspace`.


- tree virtualization;
- file-explorer-like UX;
- drag/drop support;
- rename/select/open patterns;
- allows TextForge to own the underlying workspace model.

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `@textforge/ui`, `@textforge/workspace`.


React Arborist must be treated as a **view component only**. It must not own persistence, paths, language IDs, include resolution, document identity, or security decisions.

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `@textforge/ui`, `@textforge/workspace`.


Recommended adapter model:

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `@textforge/ui`, `@textforge/workspace`.


```ts
export interface WorkspaceTreeNode {
  id: string;
  kind: "folder" | "file";
  name: string;
  parentId: string | null;
  path: string;
  documentId?: string;
  children?: WorkspaceTreeNode[];
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery, through `@textforge/ui`, `@textforge/workspace`.


### 5.8 Dexie.js for IndexedDB

**Decision:** Use Dexie.js for persistence.

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`.


- more maintainable than direct IndexedDB for multi-store workspace state;
- supports versioned schemas and migrations;
- useful for documents, folders, pipeline preferences, Lua scripts, resource metadata, and persisted UI state.

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`.


Minimum stores:

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`.


```ts
export interface TextForgeDbSchema {
  documents: PersistedDocument;
  workspaceNodes: PersistedWorkspaceNode;
  settings: PersistedSetting;
  pluginPreferences: PersistedPluginPreferences;
  luaScripts: PersistedLuaScript;
  recentViews: PersistedViewState;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`.


### 5.9 fflate for zip import/export

**Decision:** Use fflate.

**Reverse traceability:** Implemented wholly or in part by Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`.


- small and fast;
- browser-compatible;
- supports folder/workspace import/export through explicit user action;
- avoids requiring File System Access API.

**Reverse traceability:** Implemented wholly or in part by Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`.


Required use cases:

**Reverse traceability:** Implemented wholly or in part by Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`.


- import zip into current folder;
- import zip as new workspace;
- export selected folder;
- export workspace root;
- preserve relative paths;
- reject dangerous paths such as `../`, absolute paths, drive roots, or hidden system paths when appropriate.

**Reverse traceability:** Implemented wholly or in part by Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`.


### 5.10 markdown-it plus unified/remark/rehype

**Decision:** Use both, for different jobs.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


```text
Interactive preview: markdown-it
Report/document pipeline: unified + remark + rehype
```

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


- markdown-it is fast and practical for preview;
- unified/remark/rehype is better for AST-level document transformation;
- ITM-in-Markdown report generation needs structural extraction and reconstruction, not just HTML preview.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.



### 5.11 Binary resources, image assets, and PDF viewing

**Decision:** Treat binary resources as first-class workspace files, but keep them read-only unless a specific transformer generates a new derived artifact.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 4 — Markdown, local assets, and generated diagram assets; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


Required binary resource classes:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 4 — Markdown, local assets, and generated diagram assets; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


```text
Images: PNG, JPEG, GIF, WebP, SVG
Reference documents: PDF
Generated diagram assets: SVG and PNG
Future generated report assets: HTML and possibly PDF
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 4 — Markdown, local assets, and generated diagram assets; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


**Image resources** should use native browser image rendering through object URLs or blob URLs created from workspace content. Markdown image references should resolve through the workspace resolver, not through direct network fetches.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 4 — Markdown, local assets, and generated diagram assets; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


**PDF resources** should be viewable as read-only reference documents. Use PDF.js if consistent local rendering, page navigation, zoom, and text layer/search are needed. Browser-native PDF embedding is acceptable as an early fallback, but PDF.js is the better long-term fit for a controlled local workbench.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


**Generated SVG and PNG assets** should be stored in the workspace as derived files. SVG is the preferred canonical generated diagram asset. PNG should be produced by local rasterization when users need bitmap output for reports, presentations, or downstream tools.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


**Markdown-to-PDF generation** should be treated as a late-stage capability. The first reliable path should be print-optimized HTML. Direct browser-local PDF generation from complex Markdown HTML should be introduced only after the core Markdown/report pipeline is stable, because pagination, fonts, diagram scaling, SVG handling, page breaks, and cross-browser fidelity are difficult.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


Rationale:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


- Markdown projects need local image references.
- ITM and diagram pipelines need a place to store generated SVG/PNG artifacts.
- Reference PDFs are common workspace inputs even when they are not edited.
- The virtual workspace should support mixed text and binary project folders.
- PDF generation is valuable, but should not delay the core text/model/report architecture.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


### 5.12 Cytoscape.js, Sigma.js/Graphology, jsMind

**Decision:** Preserve multiple model viewers.

**Reverse traceability:** Implemented wholly or in part by Phase 7 — ITM visual projections, through `@textforge/itm`, `@textforge/diagrams`.


```text
ITM -> Cytoscape.js      rich interactive graph
ITM -> Sigma/Graphology  large graph exploration
ITM -> jsMind            mind map
ITM -> Tree viewer       hierarchy/source navigation
```

**Reverse traceability:** Implemented wholly or in part by Phase 7 — ITM visual projections, through `@textforge/itm`, `@textforge/diagrams`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 7 — ITM visual projections, through `@textforge/itm`, `@textforge/diagrams`.


No single graph/mindmap library covers all use cases well. TextForge should allow the same ITM source to be projected into multiple derived views.

**Reverse traceability:** Implemented wholly or in part by Phase 7 — ITM visual projections, through `@textforge/itm`, `@textforge/diagrams`.


### 5.13 bpmn-js and bpmn-moddle

**Decision:** Use bpmn-js for BPMN rendering and future controlled editing.

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor, through `@textforge/bpmn`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor, through `@textforge/bpmn`.


- BPMN XML is complex;
- rebuilding BPMN visualization is wasteful;
- bpmn-moddle provides BPMN XML parsing/serialization;
- bpmn-js provides the rendering/modeling surface.

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor, through `@textforge/bpmn`.


TextForge must still preserve the source-of-truth rule:

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor, through `@textforge/bpmn`.


```text
BPMN XML source -> bpmn-js viewer/modeler -> reviewed write-back patch -> XML source
```

**Reverse traceability:** Implemented wholly or in part by Phase 10 — BPMN support and first mature visual editor, through `@textforge/bpmn`.


### 5.14 Enterprise architecture and ArchiMate support

**Decision:** Add enterprise architecture and ArchiMate as first-class model workflows, parallel to BPMN support.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


- TextForge should support enterprise architecture repositories and views, not only generic graph rendering.
- ArchiMate is a structured enterprise architecture language with concepts, relationships, viewpoints, and exchange needs that should be handled through explicit ITM profiles and validation.
- The canonical authoring and transformation layer should remain ITM. ArchiMate support should therefore be implemented as a profile, transformation, validation, and viewpoint package over ITM, not as a separate hidden repository format.
- The app should support practical interchange with enterprise architecture tools through the Open Group ArchiMate Model Exchange File Format, while still allowing lightweight text-first ArchiMate-style authoring in ITM.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


Required capabilities:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


```text
ITM ArchiMate profile
  entity types, relationship types, constraints, viewpoints, styles

ArchiMate exchange import
  ArchiMate exchange XML -> ITM model package

ArchiMate exchange export
  ITM ArchiMate model/package -> ArchiMate exchange XML

ArchiMate validation
  allowed concept/relationship combinations
  required fields where applicable
  unresolved references
  view/model consistency

Enterprise architecture surfaces
  ArchiMate model explorer
  ArchiMate view renderer
  layer/aspect matrix
  relationship matrix
  dependency/impact graph
  capability/application/technology landscape views

Report integration
  generated EA views, matrices, catalogues, and traceability tables embedded into Markdown reports
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


Recommended version strategy:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


```text
Use profile packages, not hardcoded assumptions.
Provide a current ArchiMate profile as the default.
Allow additional compatibility profiles where enterprise tools still use earlier ArchiMate versions.
Keep the exchange transformer version-aware.
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


The important architectural principle is the same as for BPMN: external standards are supported through explicit profile and transformation layers, while TextForge keeps text and ITM as the inspectable source layer wherever practical.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


### 5.15 Fengari for Lua

**Decision:** Use Fengari as Lua VM only.

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


**Rationale:**

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


- browser-compatible Lua execution;
- good basis for the Lua pivot;
- allows user-defined transformations without user-provided JavaScript.

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


TextForge must own the sandbox policy, worker isolation, module whitelist, limits, bridge API, and diagnostics.

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


---

## 6. Core modules

### 6.1 Application shell

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `apps/textforge-web`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/workspace`.


- initialize services;
- host layout;
- host top-level menus/actions;
- coordinate editor, workspace, popups, diagnostics, plugins, and resource browser;
- remain thin.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `apps/textforge-web`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/workspace`.


Suggested folder:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `apps/textforge-web`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/workspace`.


```text
src/app/
  App.tsx
  AppShell.tsx
  useAppServices.ts
  useWorkspacePersistence.ts
  usePipelineActions.ts
  usePopupManager.ts
  useSourceSelectionBridge.ts
  useAttentionState.ts
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `apps/textforge-web`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/workspace`.


The rebuild should explicitly prevent `App.tsx` becoming the central orchestration module.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `apps/textforge-web`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/workspace`.


### 6.2 Workspace manager

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


- own documents;
- own folders;
- own virtual paths;
- own tabs;
- own current document;
- track dirty/current/stale state;
- increment document version on all content, filename, language, metadata, and identity changes;
- provide include resolution for ITM and Markdown/report pipelines;
- persist through Dexie.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


Interfaces:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


```ts
export interface TextDocument {
  id: string;
  fileName: string;
  languageId: string;
  text: string;
  version: number;
  dirty: boolean;
  identity: DocumentIdentity;
  folderPath?: string;
  createdAt: string;
  updatedAt: string;
}

export interface WorkspaceNode {
  id: string;
  kind: "folder" | "file";
  name: string;
  parentId: string | null;
  path: string;
  documentId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface WorkspaceManager {
  listDocuments(): TextDocument[];
  getDocument(id: string): TextDocument | undefined;
  createDocument(input: CreateDocumentInput): TextDocument;
  updateText(id: string, text: string): TextDocument;
  updateLanguage(id: string, languageId: string): TextDocument;
  renameDocument(id: string, fileName: string): TextDocument;
  moveNode(nodeId: string, newParentId: string | null, newName?: string): void;
  deleteNode(nodeId: string): void;
  resolveVirtualPath(path: string, fromDocumentId?: string): TextDocument | undefined;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


### 6.3 Virtual file system

The virtual file system is not a filesystem API wrapper. It is an application model.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


- normalize workspace paths;
- prevent path traversal;
- support folder import/export;
- support folder rename/move/delete;
- maintain stable document IDs independent of display path;
- expose read-only resolver functions to parser/report pipelines;
- prevent direct local filesystem persistence.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


Forbidden:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


- File System Access API;
- directory handles;
- automatic sync to local folders;
- silent file writes;
- network repository resolution unless explicitly introduced in a separately accredited mode.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`.


### 6.4 Storage service

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/surfaces`, `@textforge/examples-docs`.


- Dexie schema definition;
- migrations;
- workspace load/save;
- localStorage fallback only for emergency/minimal state;
- backup/export state;
- uniqueness repair for document identities/badges after restore or batch upload.

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/surfaces`, `@textforge/examples-docs`.


Suggested Dexie schema:

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/surfaces`, `@textforge/examples-docs`.


```ts
class TextForgeDb extends Dexie {
  documents!: Table<PersistedDocument, string>;
  workspaceNodes!: Table<PersistedWorkspaceNode, string>;
  settings!: Table<PersistedSetting, string>;
  pluginPreferences!: Table<PersistedPluginPreferences, string>;
  luaScripts!: Table<PersistedLuaScript, string>;
  recentViews!: Table<PersistedViewState, string>;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.2 — Dexie workspace persistence recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/surfaces`, `@textforge/examples-docs`.



### 6.5 Binary resource and asset service

TextForge should support workspace files that are not editable text documents. These files are still part of the virtual workspace and can participate in Markdown, reports, generated assets, and reference workflows.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/markdown`.


Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/markdown`.


- store binary content through the workspace storage layer;
- classify binary resources by media type and extension;
- create scoped object URLs/blob URLs for viewers;
- revoke object URLs when no longer needed;
- expose images to Markdown rendering through workspace-relative paths;
- expose PDFs to a read-only PDF viewer;
- store generated SVG and PNG artifacts into workspace folders;
- mark generated artifacts as derived from source documents/pipelines;
- keep binary resources out of CodeMirror editor tabs unless explicitly opened as source/text.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/markdown`.


Suggested interfaces:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/markdown`.


```ts
export type WorkspaceResourceKind =
  | "text"
  | "image"
  | "svg"
  | "pdf"
  | "binary"
  | "generated";

export interface WorkspaceResource {
  id: string;
  path: string;
  kind: WorkspaceResourceKind;
  mediaType: string;
  size: number;
  role: "source" | "asset" | "reference" | "generated";
  derivedFrom?: string[];
  generatedBy?: string;
  contentRef: string;
}

export interface AssetService {
  getObjectUrl(resourceId: string): Promise<string>;
  revokeObjectUrl(resourceId: string): void;
  resolveWorkspaceAsset(fromPath: string, href: string): Promise<WorkspaceResource | null>;
  writeGeneratedAsset(input: {
    path: string;
    mediaType: string;
    bytes: Uint8Array | Blob;
    derivedFrom: string[];
    generatedBy: string;
  }): Promise<WorkspaceResource>;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/markdown`.


Important distinction:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/markdown`.


```text
Editable text document: opened in CodeMirror and changed by the user.
Read-only binary resource: stored in workspace, previewed, referenced, exported, or used by pipelines.
Generated artifact: derived from a source/pipeline and stored in workspace as an output.
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 17 — Sketch and annotation resources, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/markdown`.


This distinction should be visible in the UI and in diagnostics.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 17 — Sketch and annotation resources; Phase 18 — Late PDF generation and PDF annotation, through `@textforge/assets`, `@textforge/markdown`, `@textforge/diagrams`.


### 6.6 Language registry

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 6 — ITM integration and model/report foundation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`.


- identify language from filename/content/user choice;
- expose CodeMirror language extensions;
- expose lint providers;
- expose available pipelines;
- maintain language hierarchy.

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 6 — ITM integration and model/report foundation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`.


Language IDs should include at least:

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 6 — ITM integration and model/report foundation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`.


```text
text
markdown
itm
lua
json
xml
bpmn-xml
csv
tsv
mermaid
graphviz-dot
svg
html
javascript
python
```

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 6 — ITM integration and model/report foundation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`.



Resource classifications should include non-text files:

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 6 — ITM integration and model/report foundation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`.


```text
image.png / image.jpeg / image.webp / image.gif -> resource.image
image.svg -> resource.svg, with optional source-text view
.pdf -> resource.pdf
unknown binary -> resource.binary
generated diagram SVG -> resource.svg + role=generated
generated raster image -> resource.image + role=generated
```

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 6 — ITM integration and model/report foundation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`.


Binary resources should normally open in viewers, not in CodeMirror. SVG may have both a rendered viewer and a source-text editor mode because SVG is XML text.

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 6 — ITM integration and model/report foundation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`.


### 6.7 Plugin and contribution registry

Internal TypeScript contributions should remain trusted and packaged.

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


Contribution kinds:

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


```ts
export type ContributionKind =
  | "language"
  | "editorExtension"
  | "linter"
  | "parser"
  | "transformer"
  | "viewer"
  | "exporter"
  | "pipeline"
  | "diagnosticsProvider"
  | "luaBridge";
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


Pipeline conflicts must be errors, not override points.

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


```ts
export interface RegisteredPipeline {
  pipeline: PipelineContribution;
  pluginId: string;
  enabled: boolean;
  disabledReason?: "user" | "conflict";
  conflictWith?: Array<{
    pluginId: string;
    pipelineId: string;
    pipelineName: string;
  }>;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


Registry API:

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


```ts
export interface PluginRegistry {
  registerManifest(manifest: PluginManifest): PluginRegistrationResult;
  loadPlugin(pluginId: string): Promise<void>;
  listPipelinesForLanguage(languageId: string): PipelineContribution[];
  listRegisteredPipelines(): RegisteredPipeline[];
  setPipelineEnabled(pluginId: string, pipelineId: string, enabled: boolean): void;
  listPluginDiagnostics(): Diagnostic[];
  hasUnacknowledgedPluginDiagnostics(): boolean;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


### 6.8 Pipeline runner

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 5, Phase 6, and Phase 15, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/core`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/itm`.


- execute ordered steps;
- connect contributions by ID;
- collect trace;
- collect diagnostics;
- expose intermediate values;
- allow intermediate results to open as editable documents;
- distinguish viewer, exporter, transformer, linter, and write-back steps.

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 5, Phase 6, and Phase 15, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/core`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/itm`.


Pipeline value model:

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 5, Phase 6, and Phase 15, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/core`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/itm`.


```ts
export type PipelineValueKind =
  | "text"
  | "html"
  | "svg"
  | "json"
  | "table"
  | "itm-document"
  | "graph-projection"
  | "tree-projection"
  | "bpmn-xml"
  | "diagnostics"
  | "viewer-result";

export interface PipelineValue<T = unknown> {
  kind: PipelineValueKind;
  value: T;
  mediaType?: string;
  languageId?: string;
  sourceDocumentId?: string;
  sourceVersion?: number;
  sourceMap?: SourceMapIndex;
  diagnostics?: Diagnostic[];
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 5, Phase 6, and Phase 15, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/core`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/itm`.


Trace model:

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 5, Phase 6, and Phase 15, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/core`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/itm`.


```ts
export interface PipelineTraceStep {
  stepId: string;
  contributionId: string;
  inputKind: PipelineValueKind;
  outputKind: PipelineValueKind;
  startedAt: string;
  finishedAt: string;
  diagnostics: Diagnostic[];
  serializablePreview?: string;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 5, Phase 6, and Phase 15, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/core`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/itm`.


### 6.9 ITM integration module

The ITM module is one of the highest-risk and highest-value parts.

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 7 — ITM visual projections; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 7 — ITM visual projections; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


- call `@textforge/itm` for parsing/resolution;
- provide TextForge workspace resolver functions;
- map ITM diagnostics into TextForge diagnostics;
- expose ITM document value to pipelines;
- project ITM to viewer-specific forms;
- serialize ITM where supported;
- support strict/tolerant modes.

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 7 — ITM visual projections; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


TextForge-side include resolver:

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 7 — ITM visual projections; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


```ts
export function createWorkspaceItmResolver(workspace: WorkspaceManager): ItmIncludeResolver {
  return {
    async resolveInclude(request) {
      const doc = workspace.resolveVirtualPath(request.target, request.fromUri);
      if (!doc) return undefined;
      return {
        uri: doc.fileName,
        text: doc.text,
        metadata: {
          documentId: doc.id,
          languageId: doc.languageId,
          version: doc.version
        }
      };
    }
  };
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 7 — ITM visual projections; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


ITM processing sequence:

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 7 — ITM visual projections; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


```mermaid
flowchart TD
  Raw[Raw ITM text]
  Directives[Parse directives]
  Includes[Resolve includes]
  Namespaces[Resolve namespaces]
  Packages[Resolve packages/usings]
  Entities[Parse entities, descriptions, attrs, links]
  Implicit[Generate containment and ordering]
  Overlays[Apply explicit overlays]
  Relationships[Resolve relationships]
  Types[Apply type declarations]
  Rules[Evaluate rules]
  Styles[Evaluate styles]
  Views[Expose viewpoints and views]
  Diag[Collect diagnostics]

  Raw --> Directives --> Includes --> Namespaces --> Packages --> Entities --> Implicit --> Overlays --> Relationships --> Types --> Rules --> Styles --> Views --> Diag
```

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 7 — ITM visual projections; Phase 15 — Controlled graph, diagram, and pipeline editors, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


### 6.10 Enterprise architecture and ArchiMate module

Enterprise architecture support should be implemented as a profile-driven model package on top of ITM. It should not be a single monolithic viewer.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


- provide one or more ArchiMate ITM profile packages;
- define ArchiMate element types, relationship types, layers, aspects, and viewpoints;
- validate ArchiMate relationship constraints and view consistency;
- import ArchiMate exchange XML into an ITM model package;
- export compatible ITM ArchiMate models to ArchiMate exchange XML where possible;
- generate enterprise architecture catalogues, matrices, impact graphs, dependency graphs, and viewpoint diagrams;
- expose EA/ArchiMate surfaces through the common Surface registry;
- integrate generated EA outputs into Markdown/report pipelines;
- preserve provenance between imported exchange files, ITM entities, generated views, and exported artifacts.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


Suggested files:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


```text
src/ea/
  archimateProfile.ts
  archimateTypes.ts
  archimateRelationshipRules.ts
  archimateViewpoints.ts
  archimateStyles.ts
  archimateExchangeImport.ts
  archimateExchangeExport.ts
  archimateDiagnostics.ts
  archimateCatalogues.ts
  archimateMatrices.ts
  archimateReportBlocks.ts
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


Suggested profile/resource files:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


```text
resources/profiles/archimate/
  archimate-profile.itm
  archimate-relationships.itm
  archimate-viewpoints.itm
  archimate-styles.itm
  archimate-validation-rules.itm
  archimate-report-templates.md
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


The import pipeline should be explicit:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


```text
ArchiMate exchange XML
  -> parse XML
  -> validate exchange structure
  -> map elements/relationships/views to ITM
  -> preserve source IDs and documentation
  -> emit ITM model package + diagnostics
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


The export pipeline should also be explicit:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


```text
ITM ArchiMate model package
  -> validate ArchiMate profile conformance
  -> map ITM elements/relationships/views to exchange XML
  -> emit exchange XML + diagnostics
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


Export should be conservative. If TextForge has ITM content that cannot be faithfully represented in the selected ArchiMate exchange profile, it should preserve the ITM source and emit diagnostics rather than pretending the export is lossless.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


Recommended ITM authoring pattern:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/markdown`, `@textforge/tables`, `@textforge/security-profile`.


```itm
%using archimate_profile

&customer [archimate::BusinessActor] Customer
&online_sales [archimate::BusinessProcess] Online Sales
&crm [archimate::ApplicationComponent] CRM Platform
&customer_data [archimate::DataObject] Customer Data

&online_sales !overlay
@archimate::serves:customer
@archimate::accesses:customer_data
@archimate::served_by:crm
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/itm`, `@textforge/tables`, `@textforge/markdown`, `@textforge/security-profile`.


The exact relationship names should be defined by the ArchiMate profile package rather than scattered across application code.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/itm`, `@textforge/tables`, `@textforge/markdown`, `@textforge/security-profile`.


Enterprise architecture outputs should include:

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/itm`, `@textforge/tables`, `@textforge/markdown`, `@textforge/security-profile`.


```text
Capability maps
Application landscapes
Business/application/technology layer views
Motivation-to-implementation traceability
Application dependency graphs
Interface and data-flow views
Relationship matrices
Element catalogues
Architecture decision and gap reports
```

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/itm`, `@textforge/tables`, `@textforge/markdown`, `@textforge/security-profile`.


These outputs can be rendered as surfaces, exported as SVG/PNG/HTML/CSV where appropriate, and embedded into Markdown reports.

**Reverse traceability:** Implemented wholly or in part by Phase 12 — Enterprise architecture and ArchiMate foundation; Phase 16 — ArchiMate visual editing investigation, through `@textforge/archimate`, `@textforge/itm`, `@textforge/tables`, `@textforge/markdown`, `@textforge/security-profile`.


### 6.11 Surface registry

The Surface registry replaces the older viewer-only registry concept. It registers any UI contribution that can occupy a workbench surface: editors, viewers, inspectors, consoles, diagnostics views, report previews, and generated asset previews.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 3.1, Phase 3.3, and Phase 5, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`, `@textforge/pipeline`.


Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 3.1, Phase 3.3, and Phase 5, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`, `@textforge/pipeline`.


- register surface contributions;
- choose compatible surfaces for workspace resources and pipeline outputs;
- expose common surface capabilities;
- avoid central `viewers.tsx` or `openEditor.tsx` branching;
- support both main-surface and popup placement;
- allow the same resource to be opened through different surfaces.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 3.1, Phase 3.3, and Phase 5, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`, `@textforge/pipeline`.


Core interface:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 3.1, Phase 3.3, and Phase 5, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`, `@textforge/pipeline`.


```ts
export type SurfaceKind =
  | "editor"
  | "viewer"
  | "inspector"
  | "console"
  | "diagnostics"
  | "report";

export type SurfaceCapability =
  | "edit-text"
  | "edit-rich-text"
  | "edit-table"
  | "edit-diagram"
  | "edit-model"
  | "edit-annotation"
  | "controlled-write-back"
  | "read-only"
  | "refresh"
  | "export"
  | "save-generated-resource"
  | "source-navigation"
  | "selection-sync"
  | "search"
  | "zoom"
  | "print"
  | "write-back";

export type SurfacePlacementKind = "main" | "popup" | "tab" | "split" | "detached";

export interface SurfaceContribution<TInput = SurfaceInput> {
  id: string;
  label: string;
  kind: SurfaceKind;
  capabilities: SurfaceCapability[];
  canOpen(input: TInput, context: SurfaceOpenContext): boolean;
  create(input: TInput, context: SurfaceCreateContext): SurfaceInstance;
}

export interface SurfaceInstance {
  id: string;
  contributionId: string;
  title: string;
  kind: SurfaceKind;
  capabilities: SurfaceCapability[];
  sourceBinding?: SourceBinding;
  provenance?: SurfaceProvenance;
  render(context: SurfaceRenderContext): React.ReactNode;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 3.1, Phase 3.3, and Phase 5, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`, `@textforge/pipeline`.


The registry should support a command such as:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 3.1, Phase 3.3, and Phase 5, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`, `@textforge/pipeline`.


```text
Open With...
  CodeMirror Text Editor
  Markdown Preview
  ITM Graph
  ITM Inspector
  Image Viewer
  PDF Viewer
  SVG Viewer
```

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 3.1, Phase 3.3, and Phase 5, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`, `@textforge/pipeline`.


### 6.12 Editor registry as part of the Surface registry

Do not create a separate editor subsystem that bypasses Surface lifecycle, placement, provenance, or diagnostics. Instead, define editor contributions as a specialized subset of Surface contributions.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, and Phase 14, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`, `@textforge/bpmn`, `@textforge/markdown`.


Editor contributions should be grouped by risk and maturity:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, and Phase 14, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`, `@textforge/bpmn`, `@textforge/markdown`.


| Editor class | Examples | Default posture |
|---|---|---|
| Source editors | ITM, Markdown, Lua, XML, JSON, Mermaid, DOT, SVG, CSV text | early, default, low risk |
| Standalone domain editors | BPMN modeler | early when mature and isolated |
| Structured editors | CSV grid, catalogues, matrices, ITM property forms | medium-term |
| Rich text editors | rich Markdown/report editing | later, round-trip gated |
| Visual graph editors | pipelines, flowcharts, small model graphs | later, patch-gated |
| Canvas/annotation editors | sketches, image annotation | later, resource-oriented |

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, and Phase 14, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`, `@textforge/bpmn`, `@textforge/markdown`.


A controlled editor must never silently replace the canonical source. The accepted pattern is:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, and Phase 14, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`, `@textforge/bpmn`, `@textforge/markdown`.


```text
Open canonical resource
  -> create editor session
  -> edit temporary/editor-native state
  -> preview patch or regenerated canonical source
  -> user applies or discards
  -> workspace resource version increments
  -> diagnostics and derived surfaces refresh
```

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, and Phase 14, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`, `@textforge/bpmn`, `@textforge/markdown`.


For pure source editors, CodeMirror edits the canonical text directly because the canonical source is already visible and editable. For rich/visual/structured editors, the patch boundary must be explicit.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, Phase 14, and Phase 15, through `@textforge/surfaces`, `@textforge/editors`, `@textforge/bpmn`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`.



### 6.13 Surface session manager

The Surface Session Manager tracks open surface instances independently from their placement.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


- open surfaces for resources or pipeline results;
- track title, dirty state, stale state, source binding, and provenance;
- keep editor/viewer state separate from workspace file identity;
- close, refresh, pin, and restore surfaces;
- support moving a surface between main and popup placement;
- prepare for later tabbed main surface groups.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Suggested model:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


```ts
export type SurfaceInput =
  | { kind: "workspace-resource"; resourceId: string; preferredSurfaceId?: string }
  | { kind: "pipeline-result"; resultId: string; preferredSurfaceId?: string }
  | { kind: "diagnostics"; scope?: DiagnosticScope }
  | { kind: "lua-console" };

export interface SurfaceSession {
  id: string;
  contributionId: string;
  input: SurfaceInput;
  placement: SurfacePlacement;
  title: string;
  dirty?: boolean;
  stale?: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SurfaceProvenance {
  sourceResourceIds: string[];
  sourceVersions: Record<string, number>;
  pipelineId?: string;
  generatedResourceId?: string;
  stale: boolean;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


A derived surface should become stale when any source resource version changes. A generated resource surface should also show the generated artifact path and source pipeline.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `apps/textforge-web`.


### 6.14 Placement manager and hosts

The Placement Manager decides where a surface appears. This is intentionally separate from the surface contribution itself.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Stage 1 placements:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


```ts
export type SurfacePlacement =
  | { kind: "main" }
  | { kind: "popup"; popupId: string };
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Stage 2 later adds:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


```ts
export type SurfacePlacement =
  | { kind: "main" }
  | { kind: "popup"; popupId: string }
  | { kind: "tab"; groupId: string; tabId: string };
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Future expansions may add splits and detached windows, but those should not be part of the first implementation target.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Shared chrome requirements:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `apps/textforge-web`, `@textforge/workspace`.


```text
title
resource path or source binding
stale/current badge
dirty marker where relevant
refresh
open source / reveal source
open with...
move to main
open as popup
export/download where supported
close
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `apps/textforge-web`, `@textforge/workspace`.


Hosts:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `apps/textforge-web`.


```text
MainSurfaceHost     primary work area, initially one active surface
PopupSurfaceHost    floating viewer/editor/inspector windows
Future TabHost      tabbed main surface group
Future SplitHost    split-pane workbench surfaces
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `apps/textforge-web`.


The existing popup concept becomes one placement option. Popups should remain useful for quick previews, generated diagrams, and secondary references, but they should no longer be the only way viewers appear.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `apps/textforge-web`.


### 6.15 Initial built-in surface contributions

The initial surface list should include both editors and viewers.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 11 — Tables, catalogues, and matrices, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/tables`, `@textforge/bpmn`.


```text
CodeMirrorTextEditorSurface     editable text resources
MarkdownPreviewSurface          rendered Markdown preview
ReportPreviewSurface            Markdown + ITM report preview
SourceViewerSurface             read-only source or pipeline intermediate
TableViewerSurface              CSV/TSV/table outputs
SvgViewerSurface                rendered SVG and generated SVG assets
ImageViewerSurface              PNG/JPEG/GIF/WebP assets
PdfViewerSurface                read-only PDF references
BinaryInfoSurface               fallback for unsupported binary files
ItmInspectorSurface             parsed ITM structure and diagnostics
ItmTreeSurface                  hierarchy projection
ItmMindmapSurface               jsMind projection
ItmGraphSurface                 Cytoscape projection
ItmLargeGraphSurface            Sigma/Graphology projection
BpmnViewerSurface               BPMN XML rendering
ArchiMateModelExplorerSurface   EA model tree/catalogue view
ArchiMateViewSurface            ArchiMate viewpoint rendering
ArchiMateMatrixSurface          relationship/layer/aspect matrices
EaImpactGraphSurface            dependency and impact graphs
EaCatalogueSurface              element catalogues and portfolio tables
LuaConsoleSurface               Lua execution console
DiagnosticsSurface              grouped diagnostics table
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 11 — Tables, catalogues, and matrices, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/tables`, `@textforge/bpmn`.


Required read-only resource behavior:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 11 — Tables, catalogues, and matrices, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/tables`, `@textforge/bpmn`.


```text
Image resources open read-only with zoom, fit, copy path, export/download, and reveal in workspace.
SVG resources open rendered, with optional source mode and export/store as SVG or PNG.
PDF resources open read-only with page navigation, zoom, and search if PDF.js is used.
Unsupported binaries open in BinaryInfoSurface, not CodeMirror.
Generated SVG/PNG resources show provenance and stale/current state where possible.
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 11 — Tables, catalogues, and matrices, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/tables`, `@textforge/bpmn`.


### 6.16 Source/view bridge

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 10 — BPMN support and first mature visual editor, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/bpmn`.


- map source ranges to model elements;
- map model elements to visual nodes/edges;
- support visual click to source;
- support editor cursor to viewer selection;
- support source-aware diagnostics;
- support Markdown embedded diagram/code block mapping;
- work across both main and popup placements.

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 10 — BPMN support and first mature visual editor, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/bpmn`.


Core types:

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 10 — BPMN support and first mature visual editor, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/bpmn`.


```ts
export interface SourceRange {
  documentId: string;
  version: number;
  from: number;
  to: number;
  line?: number;
  column?: number;
}

export interface ModelElementRef {
  modelKind: "itm-node" | "itm-relationship" | "directive" | "markdown-block" | "bpmn-element" | "svg-element";
  id: string;
}

export interface SourceMapIndex {
  byElement: Map<string, SourceRange[]>;
  byRange: Array<{ range: SourceRange; element: ModelElementRef }>;
}

export interface SourceBinding {
  resourceId: string;
  version: number;
  range?: SourceRange;
  element?: ModelElementRef;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 10 — BPMN support and first mature visual editor, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/bpmn`.


### 6.17 Diagnostics service

Diagnostics should be universal.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


```ts
export type DiagnosticSeverity = "error" | "warning" | "information" | "observation";

export interface Diagnostic {
  id: string;
  source: string;
  severity: DiagnosticSeverity;
  message: string;
  documentId?: string;
  range?: SourceRange;
  nodeId?: string;
  relationshipId?: string;
  ruleId?: string;
  pipelineId?: string;
  pipelineStep?: string;
  pluginId?: string;
  createdAt: string;
  acknowledged?: boolean;
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


Sources:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


- parser;
- ITM resolver;
- Markdown/report engine;
- Lua runtime;
- pipeline runner;
- plugin registry;
- viewer renderer;
- exporter;
- security checker;
- workspace importer.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


### 6.18 Markdown preview and report engine

Two paths should coexist.

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, and Phase 9, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


#### Preview path

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, and Phase 9, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


```text
Markdown source -> markdown-it -> HTML viewer
```

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, and Phase 9, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


Supports:

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, and Phase 9, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


- syntax highlighting;
- Mermaid fences;
- Graphviz/DOT fences;
- KaTeX;
- SVG popout/export;
- source-aware embedded blocks.

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, and Phase 9, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


#### Report path

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, and Phase 9, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


```text
Markdown source
  -> remark AST
  -> extract ITM blocks
  -> resolve/import model cells
  -> run ITM viewpoints
  -> generate sections/tables/diagrams/annexes
  -> rehype/HTML or Markdown output
```

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, and Phase 9, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


This report path is central to the “ITM becomes the source for report generation through embedding into Markdown” concept. The same path should support enterprise architecture publication: ArchiMate views, application catalogues, capability maps, relationship matrices, dependency graphs, and architecture traceability tables can be generated from ITM profile-conformant models and embedded into Markdown reports.

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, Phase 9, and Phase 12, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/archimate`, `@textforge/tables`.


Recommended embedded block patterns:

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, Phase 9, and Phase 12, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/archimate`, `@textforge/tables`.


````markdown
```itm name=core-model
&capability [Capability] Deployable C2
  &function [Function] Plan operation
```

```itm-pub view=capability-map import=core-model
%view capability_map
{
  viewpoint: dependency_graph
}
```
````

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, Phase 9, and Phase 12, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/archimate`, `@textforge/tables`.


Key rules:

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, Phase 9, and Phase 12, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/archimate`, `@textforge/tables`.


- Markdown is the narrative envelope;
- ITM blocks are semantic model sources;
- rendered diagrams/tables are derived;
- duplicate named model blocks should be rejected unless the syntax explicitly defines overlays/imports;
- block order should not create hidden semantics except inside a single publishing cell that explicitly imports conflicting inputs.

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 6, Phase 7, Phase 9, and Phase 12, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/archimate`, `@textforge/tables`.



#### Local image and asset resolution

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


Markdown rendering must resolve relative image paths through the virtual workspace.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


Example:

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


```markdown
![Context diagram](assets/context-diagram.svg)
![Screenshot](../images/screenshot.png)
```

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


Resolution rule:

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


```text
Markdown file path + relative href -> WorkspaceReferenceResolver -> AssetService -> scoped object URL -> rendered HTML
```

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


Requirements:

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


- resolve relative image references from the Markdown file location;
- support workspace images imported manually or via ZIP;
- support generated SVG/PNG assets stored in workspace;
- block or mark unresolved local references with diagnostics;
- block remote image URLs under the default local-only profile unless a future profile explicitly allows them;
- avoid leaking absolute local paths into rendered HTML or exported workspace artifacts.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


#### Diagram asset generation

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


Generated diagrams should be saveable into the workspace.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


Examples:

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


```text
Markdown Mermaid block -> generated/diagram-001.svg
Markdown Graphviz block -> generated/dependency-view.svg
ITM viewpoint -> generated/capability-map.svg
Generated SVG -> generated/capability-map.png
```

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


SVG export should preserve the generated vector output. PNG export should rasterize locally, normally by loading the SVG into an image/canvas pipeline and writing the resulting PNG blob back to the workspace or offering it through explicit download/export.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 9 — Markdown + ITM report generation, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`.


#### Late-stage Markdown-to-PDF generation

**Reverse traceability:** Implemented wholly or in part by Phase 18 — Late PDF generation and PDF annotation, through `@textforge/assets`, `@textforge/markdown`.


PDF generation from rendered Markdown HTML should be a late capability. It should not block Markdown preview, image embedding, report generation, or SVG/PNG asset export.

**Reverse traceability:** Implemented wholly or in part by Phase 18 — Late PDF generation and PDF annotation, through `@textforge/assets`, `@textforge/markdown`.


Recommended staged approach:

**Reverse traceability:** Implemented wholly or in part by Phase 18 — Late PDF generation and PDF annotation, through `@textforge/assets`, `@textforge/markdown`.


1. produce print-optimized HTML and CSS;
2. support browser print/save-as-PDF as a user-mediated output path;
3. evaluate client-side PDF generation only after report HTML is stable;
4. store generated PDF into the workspace only if the client-side output is reliable enough;
5. keep PDF generation behind a feature flag until pagination, diagrams, images, fonts, page breaks, and cross-browser fidelity are acceptable.

**Reverse traceability:** Implemented wholly or in part by Phase 18 — Late PDF generation and PDF annotation, through `@textforge/assets`, `@textforge/markdown`.


### 6.19 Lua runtime service

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


- run Lua snippets/documents/selections;
- discover named Lua actions;
- expose safe `tf.*` modules;
- run in Worker where possible;
- enforce limits;
- return structured diagnostics and outputs;
- integrate with pipeline/action surface.

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


Suggested files:

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


```text
src/lua/
  luaRuntime.ts
  luaBridge.ts
  luaWorker.ts
  luaModules.ts
  luaTransformService.ts
  luaScriptRegistry.ts
  luaActionRegistry.ts
  luaConsoleService.ts
  libs/
    tf.lua
    tf_tree.lua
    tf_graph.lua
    tf_table.lua
    tf_itm.lua
    tf_markdown.lua
```

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


Lua safety rules:

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


```text
No DOM.
No browser globals.
No fetch/XMLHttpRequest/WebSocket.
No localStorage/indexedDB access from Lua.
No io/os/debug libraries.
No unrestricted package searchers.
No loadfile/dofile.
No user-controlled dynamic import.
No filesystem.
No network.
```

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


### 6.20 Reusable accreditation harness

The security accreditation harness should be a **reusable browser-envelope checker**, not a TextForge-specific architectural static analyzer.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


Purpose:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


- verify that the delivered app remains inside the approved secure local-first deployment profile;
- check the safeguards that the browser or extension platform enforces;
- produce an accreditation evidence package that can be reused for similar local-first web applications;
- avoid coupling the harness to TextForge internals such as ITM, Lua action names, viewer implementations, or the exact workspace class structure.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


The harness should check:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


```text
Deployment envelope:
  CSP for static/PWA targets
  extension manifest permissions
  PWA manifest
  service-worker pattern
  final HTML entry points
  final JavaScript bundles
  final worker bundles

Network and remote code posture:
  no external runtime script URLs
  no remote module imports
  no remote workers
  no CDN runtime assets
  no unapproved external origins
  connect-src none, or only the explicitly approved origin for non-local profiles

Local filesystem authority:
  no File System Access API
  no showOpenFilePicker
  no showSaveFilePicker
  no showDirectoryPicker
  no FileSystemFileHandle
  no FileSystemDirectoryHandle
  no extension file:// access
  no nativeMessaging
  no broad host permissions

Service-worker posture:
  no arbitrary fetch proxy
  no remote importScripts
  no cache population from unapproved origins
  no service-worker weakening of the declared network profile
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


The harness should **not** check:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


```text
Whether only WorkspaceStorageGateway touches IndexedDB.
Whether only FileGateway uses ordinary user-mediated file input.
Whether every TextForge module follows ideal layering.
Whether all ITM references are semantically correct.
Whether each viewer uses the preferred internal adapter.
Whether Lua APIs are pleasant or well-designed.
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


Those are important engineering and test concerns, but they are not the reusable accreditation boundary. IndexedDB is an allowed browser storage mechanism for the application-private workspace. Ordinary user-mediated file input is allowed. The accreditation claim is that TextForge does not gain silent local filesystem authority or unapproved network/remote-code authority.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


Suggested files:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


```text
tools/accreditation/
  profile.schema.json
  profiles/
    local-only-manual-file-workspace-webapp.yml
    one-backend-manual-file-workspace-webapp.yml
  check.ts
  checks/
    checkCsp.ts
    checkStaticHtml.ts
    checkFinalBundles.ts
    checkExtensionManifest.ts
    checkPwaManifest.ts
    checkServiceWorker.ts
    checkForbiddenBrowserApis.ts
    checkRemoteAssets.ts
    checkExternalOrigins.ts
  reports/
    writeAccreditationReport.ts
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


Recommended npm scripts:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


```json
{
  "scripts": {
    "verify:envelope": "tsx tools/accreditation/check.ts --profile security/security-profile.yml --target dist",
    "verify:release": "npm run test && npm run build && npm run verify:envelope"
  }
}
```

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


The harness may include lightweight source checks as a convenience, but its authoritative role should be artifact and deployment-envelope verification. A release should be assessed against what the browser will actually load: final HTML, final JavaScript bundles, extension manifest, PWA manifest, service worker, and CSP.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


### 6.21 Resource browser

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 11 — Tables, catalogues, and matrices, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/tables`, `@textforge/bpmn`.


- expose bundled docs/examples;
- preview resources;
- open resources as editable copies;
- copy resource text;
- render Markdown resources directly;
- include manual test plans and future-feature docs.

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 11 — Tables, catalogues, and matrices, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/tables`, `@textforge/bpmn`.


Resource groups:

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 11 — Tables, catalogues, and matrices, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/tables`, `@textforge/bpmn`.


```text
README
User manual
Security whitepapers
ITM specification
Lua scripting tutorial
Lua console tutorial
Markdown examples
Mermaid examples
Graphviz examples
ITM examples
BPMN examples
Enterprise architecture examples
ArchiMate profile examples
ArchiMate exchange import/export examples
Manual test plan
Future features
```

**Reverse traceability:** Implemented wholly or in part by Phase 4 — Markdown, local assets, and generated diagram assets; Phase 7 — ITM visual projections; Phase 11 — Tables, catalogues, and matrices, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/tables`, `@textforge/bpmn`.


### 6.22 Export/import subsystem

Responsibilities:

**Reverse traceability:** Implemented wholly or in part by Phase 3, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


- explicit user-triggered import;
- explicit user-triggered export;
- zip import/export;
- SVG export;
- PNG export from SVG;
- generated SVG/PNG asset storage into workspace;
- image/reference-PDF export as workspace files or ZIP entries;
- HTML export;
- Markdown export;
- report export;
- late-stage Markdown HTML to PDF export;
- ArchiMate exchange XML import/export;
- EA catalogues/matrices export as CSV/HTML where appropriate;
- open intermediate as editable document when the intermediate is text;
- open generated binary outputs as read-only workspace resources.

**Reverse traceability:** Implemented wholly or in part by Phase 3, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


Security rules:

**Reverse traceability:** Implemented wholly or in part by Phase 3, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


- never export automatically;
- never overwrite local files silently;
- never sync to a local folder;
- never preserve absolute host paths in zip exports;
- sanitize zip paths on import.

**Reverse traceability:** Implemented wholly or in part by Phase 3, Phase 4, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`.


---

## 7. UI requirements

The UI should be a **React workbench of surfaces**, not an editor with popup-only viewers. Components should be selected for good TypeScript types, documented examples, accessibility where practical, and predictable testability. Bundle size is secondary to maintainability, agentic implementation reliability, and integration confidence.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/assets`, `apps/textforge-web`.


Recommended React UI support stack:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/assets`, `apps/textforge-web`.


```text
React Arborist        workspace tree
MainSurfaceHost       custom primary surface container
PopupSurfaceHost      custom floating surface container
Floating UI / Radix   menus, popovers, dialogs
react-resizable-panels shell-level panes, not full IDE splits at first
dnd-kit               later tab dragging and custom drag/drop outside workspace tree
TanStack Table        complex inspectors and diagnostics tables
React Flow            future controlled visual graph editing only
Zustand/custom stores app state slices
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/assets`, `apps/textforge-web`.


### 7.1 Security-visible workspace boundary

The UI should make the workspace boundary understandable without turning security into noise. TextForge should say, in user-facing wording, that workspace files are stored inside the browser-managed TextForge workspace and that exporting is required to create a copy outside the app.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `apps/textforge-web`.


Required UI cues:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `apps/textforge-web`.


- workspace root clearly labelled as an application workspace, not a live local folder;
- import actions labelled as manual import/open/ZIP import;
- export actions labelled as manual download/export/ZIP export;
- optional warning that clearing browser storage may remove workspace contents;
- generated artifacts visually distinguishable from source files where practical;
- no UI implication that TextForge is synchronizing a real local directory.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `apps/textforge-web`.


This is a product requirement, not an accreditation-harness static-analysis requirement.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3 — ZIP workspace import/export; Phase 3.2 — Dexie workspace persistence recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `apps/textforge-web`.


### 7.2 Stage 1 main layout

Stage 1 should be the first implementation target. It should support one main surface and optional popup surfaces. The main surface may be CodeMirror, a viewer, a diagnostics surface, a report preview, or a binary-resource surface.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


```text
+--------------------------------------------------------------------------------+
| Top bar: New | Open | Import Zip | Export | Actions | Surface | Diagnostics     |
+----------------------+---------------------------------------------------------+
| Workspace Explorer   | Main Surface Host                                       |
|                      |   CodeMirror editor OR Markdown preview OR ITM graph    |
| folders/files        |   OR Image/PDF/SVG/BPMN/report/diagnostics surface      |
| resources shortcut   |                                                         |
+----------------------+---------------------------------------------------------+
| Status bar: resource | surface | version | dirty/stale | diagnostics | profile   |
+--------------------------------------------------------------------------------+
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


Important Stage 1 rules:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


```text
Double-clicking a text file may open CodeMirror in the main surface.
Double-clicking an image/PDF/SVG may open the matching read-only viewer in the main surface.
Pipeline previews may open in the main surface or as popup.
A surface can be moved between main and popup if supported.
The main surface is not synonymous with CodeMirror.
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`.


### 7.3 Stage 2 target: advanced tabbed main surfaces

Stage 2 is the target advanced workbench model, but it should be implemented later in the roadmap after the basic surface abstraction is stable. The roadmap may introduce a narrow Phase 3.1 main-session tab strip earlier for usability; that earlier strip is not the full Stage 2 tab-group model.

**Reverse traceability:** Implemented wholly or in part by Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`, `@textforge/workspace`.


Stage 2 adds a tabbed main surface group where editors and viewers are peers:

**Reverse traceability:** Implemented wholly or in part by Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`, `@textforge/workspace`.


```text
+--------------------------------------------------------------------------------+
| Top bar                                                                         |
+----------------------+---------------------------------------------------------+
| Workspace Explorer   | Tabs: [model.itm] [Graph View] [Report Preview] [PDF]   |
|                      +---------------------------------------------------------+
|                      | Active surface                                          |
+----------------------+---------------------------------------------------------+
| Status / diagnostics summary                                                    |
+--------------------------------------------------------------------------------+
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`, `@textforge/workspace`.


Tab requirements:

**Reverse traceability:** Implemented wholly or in part by Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`, `@textforge/workspace`.


- surface icon or type marker;
- resource/file name or derived view title;
- dirty marker for editable resources;
- stale marker for derived surfaces;
- close button;
- optional pinned state;
- `Open With...`;
- `Move to popup`;
- later tab reorder via dnd-kit.

**Reverse traceability:** Implemented wholly or in part by Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`, `@textforge/workspace`.


Stage 2 should not introduce full split-pane complexity yet. It should simply allow multiple surfaces in the main area.

**Reverse traceability:** Implemented wholly or in part by Phase 3.4 — Shapez.io-style document badges and deterministic resource identity; Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`, `@textforge/workspace`.


### 7.4 Future layout expansions

After Stage 2, the following can be considered:

**Reverse traceability:** Implemented wholly or in part by Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`.


```text
Stage 3: split panes, open to side, bottom diagnostics/console panel
Stage 4: saved layouts and workspace layout restoration
Stage 5: detached browser windows or multi-monitor workflows
```

**Reverse traceability:** Implemented wholly or in part by Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`.


These are intentionally future expansions. The rebuild should design the Surface interfaces so they are possible, but should not require them for the first rebuild.

**Reverse traceability:** Implemented wholly or in part by Phase 13 — Stage 2 advanced tabbed main surfaces, through `@textforge/surfaces`, `@textforge/ui`, `@textforge/core`.


### 7.5 Workspace explorer UI

Use React Arborist for:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/examples-docs`.


- folders/files;
- expand/collapse;
- rename;
- drag/drop move;
- context menu;
- multi-select if needed;
- open on click/double click;
- dirty indicators;
- generated/stale indicators;
- language/resource icons;
- document badges.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/examples-docs`.


Required context menu actions:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/examples-docs`.


```text
New File
New Folder
Rename
Duplicate
Move
Delete
Import Files
Import Zip Here
Export Folder as Zip
Download File
Open With...
Open in Main Surface
Open as Popup
Copy Path
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.4 — Shapez.io-style document badges and deterministic resource identity, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/examples-docs`.


### 7.6 Binary resource UI

The workspace explorer should show read-only binary resources distinctly from editable text files.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


Required UI behavior:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


```text
Image file double-click      -> open ImageViewerSurface, preferably in main surface
SVG double-click             -> open SvgViewerSurface, with optional source mode
PDF double-click             -> open PdfViewerSurface
Unsupported binary file      -> open BinaryInfoSurface
Generated SVG/PNG            -> show generated/provenance marker
Markdown unresolved image    -> diagnostic plus broken-reference marker in preview
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


Surface toolbar requirements:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


```text
Images/SVGs: zoom, fit, copy path, export/download, reveal in workspace
SVGs: export as SVG, rasterize/store as PNG
PDFs: page navigation, zoom, search if supported, download/export, reveal in workspace
Generated assets: show source pipeline and stale/current state
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


The UI should avoid suggesting that PDFs and raster images are editable source files. They are workspace resources, references, or generated artifacts.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`.


### 7.7 Surface chrome

All surfaces should share a common outer chrome where practical.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


Common controls:

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


```text
Title / resource path / view title
Surface type
Dirty marker
Stale/current marker
Refresh, if derived
Open source / reveal in workspace
Open With...
Move to main
Open as popup
Export/download, if supported
Search, if supported
Zoom/Fit, if supported
Close
```

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


The chrome should adapt to capability flags. For example, a PDF surface shows page/zoom controls, while a CodeMirror surface shows editor actions and a generated report surface shows refresh/export/print controls.

**Reverse traceability:** Implemented wholly or in part by Phase 1 — Workspace and Stage 1 surface skeleton; Phase 3.1 — React workbench shell and UI recovery; Phase 3.3 — Command palette and contribution-driven shell commands, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/security-profile`, `@textforge/core`.


### 7.8 Diagnostics UI

Diagnostics should be available both as a popup and as a main surface.

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition; Phase 11 — Tables, catalogues, and matrices, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`, `@textforge/tables`, `@textforge/bpmn`.


Diagnostics button should indicate attention when any of these exist:

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition; Phase 11 — Tables, catalogues, and matrices, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`, `@textforge/tables`, `@textforge/bpmn`.


- document diagnostics;
- plugin conflicts;
- security verification failures;
- pipeline failures;
- Lua runtime errors;
- workspace import warnings.

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition; Phase 11 — Tables, catalogues, and matrices, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`, `@textforge/tables`, `@textforge/bpmn`.


Diagnostics view should support grouping by:

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition; Phase 11 — Tables, catalogues, and matrices, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`, `@textforge/tables`, `@textforge/bpmn`.


```text
Document
Severity
Source
Pipeline
Plugin
Security check
```

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition; Phase 11 — Tables, catalogues, and matrices, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`, `@textforge/tables`, `@textforge/bpmn`.


### 7.9 Plugin manager UI

The plugin manager can initially be a popup or dialog, but should later be usable as a main surface if it grows.

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


Must show:

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


- packaged plugins;
- loaded/failed status;
- contribution list;
- surface contributions;
- pipelines;
- enabled/disabled pipeline state;
- conflicts;
- user override selection;
- persisted preferences.

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


Pipeline conflicts must be visible and resolvable by the user.

**Reverse traceability:** Implemented wholly or in part by Phase 3.3 — Command palette and contribution-driven shell commands; Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/ui`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `apps/textforge-web`, `@textforge/pipeline`.


### 7.10 Lua console UI

The Lua console should be a surface, not a special case. It can open in the main area or popup.

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


Can use xterm.js if a terminal-like interaction is desired.

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


Required actions:

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


- run current Lua document;
- run selection;
- run snippet;
- list actions;
- inspect last result;
- open last result as document or surface;
- show diagnostics.

**Reverse traceability:** Implemented wholly or in part by Phase 8 — Lua automation, through `@textforge/lua`, `@textforge/pipeline`.


---

## 8. Relationships between modules

```mermaid
flowchart TD
  AppShell --> WorkspaceManager
  AppShell --> PluginRegistry
  AppShell --> PipelineRunner
  AppShell --> PopupManager
  AppShell --> DiagnosticsService
  AppShell --> ResourceBrowser

  WorkspaceManager --> StorageService
  WorkspaceManager --> VirtualFileSystem
  WorkspaceManager --> DocumentIdentityService
  WorkspaceManager --> AssetService

  Editor --> LanguageRegistry
  Editor --> DiagnosticsService
  Editor --> SourceViewBridge

  PipelineRunner --> PluginRegistry
  PipelineRunner --> ItmService
  PipelineRunner --> MarkdownService
  PipelineRunner --> LuaService
  PipelineRunner --> ViewerRegistry
  PipelineRunner --> DiagnosticsService

  ItmService --> WorkspaceResolver
  MarkdownService --> ItmService
  MarkdownService --> AssetService
  MarkdownService --> ViewerRegistry

  ViewerRegistry --> PopupManager
  PopupManager --> SourceViewBridge

  LuaService --> LuaWorker
  LuaWorker --> LuaModules
  LuaService --> DiagnosticsService

  SecurityVerifier --> DiagnosticsService
```

**Reverse traceability:** Implemented wholly or in part by Phase 5 — Contribution registries and package composition, through `@textforge/core`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/ui`.


---


## 9. Repository pivot and preservation strategy

TextForge should keep its existing repository name and Git history while moving to the modular rebuild. The pivot should be explicit, reversible, and easy for coding agents to understand.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


The recommended approach is:

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


```text
1. Preserve the current implementation with tag `textforge-v1-final`.
2. Preserve the same point with archival branch `archive/v1-current`.
3. Create `rewrite/v2-monorepo` for the modular greenfield rebuild.
4. Preserve selected historical docs, specifications, examples, fixtures, whitepapers, tests, and attribution material.
5. Remove old implementation files from the rewrite branch after preservation.
6. Add the pnpm workspace skeleton and package folders.
7. Make one clear pivot commit before feature work begins.
```

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


This avoids a separate `TextForge2` repository while avoiding a confusing side-by-side codebase. The old implementation remains available through normal Git history, the archival branch, and the final tag. The new implementation receives a clean workspace, clean dependency tree, and clean package boundaries.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


## 10. Companion roadmap set and authority split

The implementation roadmap is deliberately separated from this main architecture paper. This document defines the target architecture, invariants, security posture, surface model, and long-lived design rules. The companion V15d roadmap documents define the authoritative implementation sequence, package ownership, repository strategy, and current phase state.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation; Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy, through `apps/textforge-web`, `packages/*`, `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


Use the roadmap set as follows:

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation; Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy, through `apps/textforge-web`, `packages/*`, `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


```text
roadmap/AGENTS_START_HERE.md
  First operational instructions for every coding agent run.

roadmap/00_package_aware_roadmap.md
  Authoritative phase order, including the runnable-shell checkpoint and package-by-package phase flow.

roadmap/01_repository_and_package_strategy.md
  Authoritative repository, package-boundary, and versioning strategy.

roadmap/RAPID.md
  Authoritative current-status pointer and append-only execution log.

roadmap/packages/*.md
  Authoritative package-level phase ownership, dependency rules, and definition-of-done guidance.
```

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation; Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy, through `apps/textforge-web`, `packages/*`, `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


When this whitepaper and the roadmap set overlap, the roadmap set is authoritative for implementation sequencing and package rollout. The correct fix for drift is to update or reduce the duplicate implementation text here, not to maintain a second phase plan inside the whitepaper.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation; Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy, through `apps/textforge-web`, `packages/*`, `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.



## 11. Testing strategy

### 11.1 Unit tests

Required:

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 3.2 — Dexie workspace persistence recovery; Phase 8 — Lua automation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/lua`, `@textforge/pipeline`.


- workspace path normalization;
- document versioning;
- Dexie migrations;
- zip path sanitizer;
- plugin conflict handling;
- pipeline runner sequencing;
- diagnostics merge/grouping;
- ITM resolver adapter;
- Markdown block extraction;
- Lua bridge serialization;
- source range mapping.

**Reverse traceability:** Implemented wholly or in part by Phase 2 — Source-editor coverage and language foundation; Phase 3.2 — Dexie workspace persistence recovery; Phase 8 — Lua automation, through `@textforge/core`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/workspace`, `apps/textforge-web`, `@textforge/ui`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/lua`, `@textforge/pipeline`.


### 11.2 Parser/model tests

Required:

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 12 — Enterprise architecture and ArchiMate foundation, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/archimate`, `@textforge/tables`.


- ITM include resolution from workspace;
- missing include diagnostics;
- circular include diagnostics;
- duplicate ID / overlay behavior;
- namespaces with `::` and typed links with `:`;
- multiline directives;
- descriptions and attribute blocks;
- selectors;
- styles;
- view/viewpoint deltas;
- ArchiMate profile validation fixtures;
- ArchiMate exchange import/export fixtures;
- lossy ArchiMate export diagnostics.

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 12 — Enterprise architecture and ArchiMate foundation, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/archimate`, `@textforge/tables`.


### 11.3 UI tests

Required:

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/core`.


- create/rename/delete/move in workspace tree;
- tab reorder;
- stale popup state;
- diagnostics attention indicators;
- plugin conflict UI;
- viewer popup controls;
- Markdown embedded diagram popout;
- source/view click navigation;
- ArchiMate model explorer and matrix surfaces;
- EA view generation and stale-state handling.

**Reverse traceability:** Implemented wholly or in part by Phase 3.1 — React workbench shell and UI recovery; Phase 13 — Stage 2 advanced tabbed main surfaces, through `apps/textforge-web`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/editors`, `@textforge/assets`, `@textforge/security-profile`, `@textforge/core`.


### 11.4 Security and accreditation tests

Security tests should be split into two groups.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/core`, `@textforge/security-profile`, `@textforge/ui`, `@textforge/examples-docs`, `roadmap/`.


#### 11.4.1 Reusable accreditation-envelope checks

These are application-independent checks that can be reused across secure local-first web apps:

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


```text
CSP/static target:
  no unapproved connect-src
  no remote scripts/modules/workers
  no CDN runtime assets
  no object/embed escape path

Extension target:
  no broad host permissions
  no <all_urls>
  no file:// access
  no nativeMessaging
  no arbitrary content script injection

PWA target:
  service worker is same-origin constrained
  no arbitrary fetch proxy
  no remote importScripts
  no unapproved external cache population

Built artifacts:
  no showOpenFilePicker
  no showSaveFilePicker
  no showDirectoryPicker
  no FileSystemFileHandle
  no FileSystemDirectoryHandle
  no remote code-loading patterns
  no external origins inconsistent with the declared profile
```

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


These checks support accreditation because they verify browser-enforced safeguards and privileged browser API absence.

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


#### 11.4.2 TextForge project security tests

These are ordinary project tests. They are useful, but they should not be confused with the reusable accreditation harness:

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


```text
Lua cannot access DOM/network/filesystem/browser globals.
Lua cannot use forbidden libraries such as io/os/debug/loadfile/dofile.
Zip import rejects path traversal and absolute paths.
Workspace import/export roundtrips preserve virtual paths.
Markdown/SVG rendering does not execute active content unexpectedly.
Reference resolution stays inside the virtual workspace for local-only profiles.
```

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


The distinction matters. The reusable harness verifies the accredited browser envelope. TextForge tests verify that TextForge's own features are implemented well.

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


### 11.5 Golden-output tests

Required:

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 7, Phase 9, Phase 11, and Phase 12, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/tables`, `@textforge/bpmn`, `@textforge/archimate`.


- Markdown preview fixtures;
- Markdown image-reference fixtures;
- generated SVG fixtures;
- generated PNG smoke fixtures where stable;
- print-optimized HTML report fixtures;
- ITM parse fixtures;
- ITM-to-graph fixtures;
- ITM-to-report fixtures;
- Graphviz/Mermaid SVG smoke fixtures;
- BPMN XML render smoke fixtures;
- ArchiMate exchange import/export fixtures;
- ArchiMate matrix/catalogue fixtures;
- EA report block fixtures;
- zip import/export roundtrip fixtures.

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 7, Phase 9, Phase 11, and Phase 12, through `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/assets`, `@textforge/itm`, `@textforge/tables`, `@textforge/bpmn`, `@textforge/archimate`.


---

## 12. Files and documents to preserve, migrate, or recreate

The rebuild should maintain the following source-of-truth documents or their updated equivalents.

**Reverse traceability:** Implemented wholly or in part by Phase -1, Phase 0, Phase 6, Phase 12, and Phase 19, through `@textforge/examples-docs`, `@textforge/security-profile`, `@textforge/itm`, `@textforge/archimate`, `@textforge/markdown`.


### 12.1 Product and architecture documents

| File | Preserve as | Reason |
|---|---|---|
| `README.md` | top-level product README | Captures current user-facing scope, local-first posture, supported formats, Lua pivot, resource browser, and build targets. |
| `Still to do.md` | backlog / migration checklist | Identifies unfinished items that must not be lost. |
| `textforge_update_implementation_guide.md` | implementation guidance | Contains concrete decisions on plugin conflicts, ITM dependency, renderer registry, versioning, and no-network checks. |
| `textforge_lua_pivot_whitepaper.md` | security and scripting architecture | Defines the Lua pivot and sandbox posture. |
| `textforge_itm_single_object_model_whitepaper.md` | canonical model architecture | Defines ITM as the single structural object model. |
| secure webapp accreditation whitepaper | accreditation/security rationale | Defines the security claim, especially no network and no silent local file access/modification. |
| workspace/security rationale with virtual workspace update | workspace rationale | Defines IndexedDB workspace, folder zip import/export, and no File System Access API. |

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


### 12.2 Format specifications

| File | Preserve as | Reason |
|---|---|---|
| `indented_text_model_format_description_updated.md` | ITM specification | Required canonical model spec. |
| `docs/itm-tree-style-support.md` | viewer style support reference | Required if tree styles are preserved. |
| `docs/itm-mindmap-style-support.md` | viewer style support reference | Required for mindmap styling. |
| `docs/itm-graph-style-support.md` | viewer style support reference | Required for graph styling. |

**Reverse traceability:** Implemented wholly or in part by Phase 6 — ITM integration and model/report foundation; Phase 12 — Enterprise architecture and ArchiMate foundation, through `@textforge/itm`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/archimate`, `@textforge/tables`.


### 12.3 User-facing resources

| File/group | Preserve as | Reason |
|---|---|---|
| User manual | bundled resource | Required for offline documentation. |
| Lua scripting tutorial | bundled resource | Required for user automation. |
| Lua console tutorial | new bundled resource | Missing/needed. |
| Manual test plan | bundled resource | Should be maintained. |
| Future features docs | bundled resource | Should be maintained. |
| Markdown examples | bundled examples | Needed for preview/report workflows. |
| Mermaid examples | bundled examples | Needed for diagram rendering. |
| Graphviz examples | bundled examples | Needed for DOT workflows. |
| ITM examples | bundled examples | Needed for model workflows. |
| BPMN examples | bundled examples | Needed for BPMN workflows. |
| Enterprise architecture examples | bundled examples | Needed for EA workflows. |
| ArchiMate profile examples | bundled examples | Needed for ArchiMate modelling workflows. |
| ArchiMate exchange import/export examples | bundled examples | Needed to validate interoperability workflows. |
| Editor round-trip fixtures | bundled/test resource | Required for Markdown, BPMN, tables, Mermaid, and future visual editors. |
| Dependency licensing policy | repository policy document | Required to keep TextForge open-source-compatible. |

**Reverse traceability:** Implemented wholly or in part by Phase 4, Phase 8, Phase 10, Phase 12, Phase 17, and Phase 19, through `@textforge/markdown`, `@textforge/diagrams`, `@textforge/lua`, `@textforge/bpmn`, `@textforge/archimate`, `@textforge/assets`, `@textforge/examples-docs`.


### 12.4 Code assets to preserve conceptually

Even in a full rewrite, preserve these conceptual assets:

**Reverse traceability:** Implemented wholly or in part by Phase -1, Phase 3.4, Phase 4, Phase 6, Phase 8, Phase 12, and Phase 19, through `@textforge/examples-docs`, `@textforge/workspace`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/itm`, `@textforge/lua`, `@textforge/archimate`, `@textforge/security-profile`.


| Existing or intended asset | Preserve concept |
|---|---|
| CodeMirror setup | editor extension model, language switching, lint surface |
| popup host | source-aware, stale-aware viewer windows |
| plugin registry | trusted contribution registry, but with conflict-safe pipeline registration |
| pipeline trace | inspectable intermediate values |
| Lua runtime | restricted Fengari-based user automation |
| resource browser | bundled local documentation and examples |
| Shapez-style document badges | deterministic document identity, with tests and uniqueness repair |
| Enterprise architecture and ArchiMate profile assets | ArchiMate profile, validation, viewpoints, styles, import/export mappings |
| ITM viewers | tree, mindmap, Cytoscape, Sigma, inspector |
| Markdown embedded artifact rendering | Mermaid, Graphviz, KaTeX, code highlighting, local image resolution, SVG popout/export, PNG storage |
| security verification scripts | extend into browser no-network smoke and accreditation checks |

**Reverse traceability:** Implemented wholly or in part by Phase -1, Phase 3.4, Phase 4, Phase 6, Phase 8, Phase 12, and Phase 19, through `@textforge/examples-docs`, `@textforge/workspace`, `@textforge/ui`, `@textforge/surfaces`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/itm`, `@textforge/lua`, `@textforge/archimate`, `@textforge/security-profile`.


---

### 12.5 Security whitepaper integration notes

When maintaining this rebuild document, preserve the distinction from the secure webapp accreditation whitepaper:

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


- the application-private workspace is allowed and can be persisted in IndexedDB;
- the workspace is not a live local filesystem mirror;
- local file exchange is manual import/export, including ZIP import/export for folders and workspace root;
- the File System Access API, persistent handles, real directory handles, broad extension permissions, native messaging, and remote code loading remain forbidden in the accredited local profile;
- the accreditation harness verifies browser-enforced safeguards and deployment artifacts;
- the harness should remain reusable across apps and should not attempt to prove every internal TextForge gateway or layering rule.

**Reverse traceability:** Implemented wholly or in part by Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy; Phase 3 — ZIP workspace import/export; Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/workspace`, `@textforge/examples-docs`.


## 13. Coding-agent implementation guidance

This section records architecture-level guardrails for implementation work. Operational run instructions, current phase control, and repository-state handling belong to the roadmap set and RAPID log, not to this whitepaper.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation; Phase 0 — Repository foundation, package skeleton, security envelope, and dependency policy, through `@textforge/examples-docs`, `@textforge/core`, `@textforge/security-profile`.


### 13.1 General rules for the coding agent

1. Do not introduce app-code network access.
2. Do not introduce File System Access API.
3. Do not introduce user-provided JavaScript plugin execution.
4. Do not make viewers own canonical models.
5. Do not silently override duplicate pipeline IDs.
6. Do not mutate source from visual viewers without explicit write-back review.
7. Do not create a central viewer god module.
8. Do not parse ITM locally if `@textforge/itm` should own the behavior.
9. Do not store derived outputs as hidden source of truth.
10. Do not add dependencies that require remote assets at runtime.
11. Do not implement enterprise architecture or ArchiMate as opaque diagram-only data; keep profiles, validation, import/export, and generated views explicit.
12. Do not add rich, visual, table, or model editors without an explicit write-back contract and source-editor fallback.
13. Do not add dependencies that violate the open-source dependency policy.
14. Do not make rich Markdown editing the default until round-trip tests pass.
15. Do not use React Flow as a large-graph viewer; use it only for controlled editing surfaces.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/examples-docs`.


### 13.2 Preferred folder structure

```text
src/
  app/
  workspace/
  storage/
  security/
  domain/
  languages/
  plugins/
  pipelines/
  itm/
  markdown/
  lua/
  viewers/
  resources/
  export/
  tests/
```

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


### 13.3 Implementation sequencing authority

This whitepaper must not maintain its own phase summary, phase-number mapping, or package rollout checklist. Those details change more frequently than the architectural doctrine in this paper and are therefore owned by the companion roadmap set.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


For implementation sequencing, always use:

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


- `roadmap/00_package_aware_roadmap.md` for the authoritative phase order.
- `roadmap/01_repository_and_package_strategy.md` for runnable-shell and repository-boundary rules.
- `roadmap/packages/*.md` for package-specific phase participation.
- `roadmap/RAPID.md` for the current active phase and execution state.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


When updating this whitepaper, keep only the architecture-level statements that remain valid across multiple roadmap revisions. If a change affects phase order, package creation timing, or current work sequencing, update the roadmap documents instead of adding another implementation summary here.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


### 13.4 Cross-document maintenance rule

If the whitepaper and the roadmap set ever diverge again, treat that as documentation drift:

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


1. keep the architectural target state here;
2. keep implementation order and current phase control in the roadmap set;
3. remove or shorten duplicated implementation guidance in this whitepaper;
4. record the correction in `roadmap/RAPID.md`.

**Reverse traceability:** Implemented wholly or in part by Phase -1 — Repository pivot and archival preservation, through `apps/textforge-web`, `packages/*`.


---


### 13.8 Binary-resource and export completeness requirements

The Surface-based workbench architecture must not remove the resource and export requirements. The following items remain mandatory:

**Reverse traceability:** Implemented wholly or in part by Phase 3, Phase 3.2, Phase 4, Phase 9, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`, `apps/textforge-web`, `@textforge/ui`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/itm`.


```text
Read-only binary workspace resources are first-class workspace files.
Images can be imported, viewed, embedded in Markdown, and resolved through workspace-relative paths.
Reference PDFs can be imported and opened read-only.
SVG resources can be viewed rendered and optionally opened as source text.
Generated diagrams can be stored into the workspace as SVG.
Generated SVG can be rasterized locally to PNG and stored into the workspace or explicitly exported.
Generated assets carry provenance and stale/current state where practical.
Markdown preview resolves local images through the workspace resolver, not network fetches.
Remote image references are blocked or diagnosed in the local-only profile.
Unsupported binaries open in an information surface rather than CodeMirror.
Markdown HTML-to-PDF remains late-stage and must not block the core report pipeline.
Print-optimized HTML is the first reliable report-output path.
```

**Reverse traceability:** Implemented wholly or in part by Phase 3, Phase 3.2, Phase 4, Phase 9, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`, `apps/textforge-web`, `@textforge/ui`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/itm`.


The Surface architecture strengthens these requirements because images, SVGs, PDFs, and generated report previews become peer surfaces rather than popup-only side effects.

**Reverse traceability:** Implemented wholly or in part by Phase 3, Phase 3.2, Phase 4, Phase 9, Phase 17, and Phase 18, through `@textforge/workspace`, `@textforge/security-profile`, `@textforge/assets`, `apps/textforge-web`, `@textforge/ui`, `@textforge/pipeline`, `@textforge/markdown`, `@textforge/diagrams`, `@textforge/itm`.


## 14. Definition of done

The rebuild is successful when:

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


1. A user can maintain a multi-folder virtual workspace entirely in the browser.
2. The workspace persists in IndexedDB and can be manually imported/exported as zip.
3. No feature silently reads or writes local files.
4. No application code uses network APIs.
5. CodeMirror is available as the primary text-editing surface, but viewers and editors share the common Surface model.
6. Pipelines are explicit, traceable, and conflict-safe.
7. ITM is the canonical structural model for tree/graph/report workflows.
8. Markdown can render local diagrams, math, code, and workspace-local images.
9. Markdown can embed/import ITM blocks for report generation.
10. Enterprise architecture and ArchiMate models can be authored through ITM profiles, validated, rendered as views/matrices/catalogues, and exchanged through a version-aware exchange XML path where practical.
11. Images and reference PDFs can be stored and previewed as read-only workspace resources.
11. Generated SVG and PNG diagram assets can be stored back into the workspace.
12. Markdown-to-PDF has a documented late-stage path and is not required for the core MVP.
10. Lua automation works without exposing browser, DOM, network, or filesystem APIs.
11. Viewer popups are stale-aware and source-aware.
12. Diagnostics are common across parsers, plugins, pipelines, viewers, Lua, workspace, and security checks.
13. Reusable browser-envelope accreditation verification is part of the release check path.
14. The app runs as a static local build and as a browser extension under the same security posture.

**Reverse traceability:** Implemented wholly or in part by Phase 19 — Release-envelope verification and accreditation evidence, through `@textforge/security-profile`, `@textforge/examples-docs`.


---

### 14.1 Editor-specific definition of done

An editor contribution is done only when:

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, Phase 11, Phase 14, Phase 15, Phase 16, and Phase 17, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`, `@textforge/bpmn`, `@textforge/tables`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`, `@textforge/security-profile`, `@textforge/archimate`.


1. it is registered as a Surface contribution;
2. it declares whether it is source, rich-text, table, diagram, model, annotation, or hybrid;
3. it declares the canonical resource format it edits;
4. it has a source-editor fallback;
5. it defines supported edit operations and unsupported constructs;
6. it produces a patch, regenerated canonical source, or explicit workspace update;
7. it increments workspace resource versions correctly;
8. it refreshes diagnostics and stale derived surfaces;
9. it has round-trip tests appropriate to its format;
10. its dependencies pass the open-source licensing gate.

**Reverse traceability:** Implemented wholly or in part by Phase 1, Phase 2, Phase 10, Phase 11, Phase 14, Phase 15, Phase 16, and Phase 17, through `@textforge/workspace`, `@textforge/surfaces`, `@textforge/ui`, `@textforge/editors`, `@textforge/assets`, `@textforge/core`, `@textforge/bpmn`, `@textforge/tables`, `@textforge/markdown`, `@textforge/pipeline`, `@textforge/itm`, `@textforge/diagrams`, `@textforge/security-profile`, `@textforge/archimate`.


## 15. Final architectural position

The rebuilt TextForge should be deliberately narrow in its security claim, React-based in its implementation posture, and deliberately broad in its structured-text usefulness.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


It should not claim to protect users from every malicious transformation. A Lua script or built-in transformation can still damage the text the user chooses to process. The stronger and more defensible claim is:

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


> TextForge runs inside a browser-enforced local-first security envelope: no unapproved network egress, no remote code loading, no privileged silent local filesystem access, an application-private workspace, and manual user-mediated file import/export. The reusable accreditation harness verifies that envelope rather than attempting to prove all internal implementation layering.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


That claim is compatible with powerful local authoring, binary workspace resources, local image embedding, generated SVG/PNG assets, model transformation, enterprise architecture modelling, ArchiMate viewpoints, graph visualization, Markdown publishing, Lua automation, and controlled visual editing.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


The result is not just an editor. It is a local, inspectable, accreditation-friendly workbench for text-based digital engineering artifacts, including enterprise architecture and process-modelling assets, where richer editors exist to forge canonical text and model resources rather than replace them.

**Reverse traceability:** Implemented wholly or in part by all implementation phases, through `apps/textforge-web`, `@textforge/core`, `@textforge/workspace`, `@textforge/surfaces`, `@textforge/pipeline`, `@textforge/security-profile`.


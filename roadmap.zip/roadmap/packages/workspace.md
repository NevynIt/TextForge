# @textforge/workspace — Package Implementation Guide

## Purpose

Virtual workspace, text/binary resources, folders, Dexie persistence, ZIP import/export, metadata, provenance, and workspace-relative references.

## Ownership rule

`@textforge/workspace` owns its contracts and tests. Other packages should interact with it through public interfaces and contribution manifests, not private imports.

## Agent note

When this package is updated, the agent must also update `roadmap/RAPID.md` and review the package milestone plan below. If implementation reality changes the plan, update the roadmap/package guide in the same commit.

## Allowed dependencies

Internal dependencies:

- `@textforge/core`

Third-party candidates: Dexie, fflate. All third-party dependencies must pass the open-source license gate.

## Public surface

WorkspaceService, persisted-workspace helpers, Dexie storage/reset helpers, WorkspaceResource, WorkspaceFolder, WorkspaceMutation, WorkspaceQuery, WorkspaceReferenceResolver, and workspace manifest APIs.

## Milestone plan

### Phase 1 — Workspace and Stage 1 surface skeleton

Implementation anchors:

- Architecture paragraphs: `ARCH-4.1-P01..P02`, `ARCH-4.2-P01..P03`, `ARCH-4.3-P01..P07`, `ARCH-5.2-P01..P06`, `ARCH-5.3-P01..P05`, `ARCH-5.6-P01..P04`, `ARCH-5.11-P01..P09`, `ARCH-6.2-P01..P04`, `ARCH-6.3-P01..P05`, `ARCH-6.5-P01..P07`, `ARCH-6.11-P01..P07`, `ARCH-6.12-P01..P05`, `ARCH-6.13-P01..P05`, `ARCH-6.14-P01..P06`, `ARCH-6.15-P01..P04`, `ARCH-7.1-P01..P04`, `ARCH-7.2-P01..P04`, `ARCH-7.5-P01..P04`, `ARCH-7.6-P01..P06`, `ARCH-7.7-P01..P04`, `ARCH-14.1-P01..P02`.
- pnpm packages: Phase 1: `pnpm --filter @textforge/workspace add @textforge/core@workspace:*`


Create. Virtual files/folders, resource IDs, text/binary resource metadata, Dexie schema, basic create/open/save/delete/rename/move APIs. The schema may exist before the real Dexie runtime is wired.

### Phase 3 — ZIP workspace import/export

Implementation anchors:

- Architecture paragraphs: `ARCH-5.9-P01..P05`, `ARCH-6.3-P01..P05`, `ARCH-6.5-P01..P07`, `ARCH-6.22-P01..P04`, `ARCH-7.1-P01..P04`, `ARCH-13.8-P01..P03`.
- pnpm packages: Phase 3: `pnpm --filter @textforge/workspace add fflate`


Update. Add fflate ZIP import/export, selected-folder export, full-workspace export, workspace manifest, path normalization, conflict policy.

### Phase 3.2 — Dexie workspace persistence recovery

Implementation anchors:

- Architecture paragraphs: `ARCH-5.8-P01..P05`, `ARCH-6.2-P01..P04`, `ARCH-6.4-P01..P04`, `ARCH-7.1-P01..P04`, `ARCH-11.1-P01..P02`, `ARCH-13.8-P01..P03`.
- pnpm packages: Phase 3.2: `pnpm --filter @textforge/workspace add dexie`


Update. Add Dexie as a real runtime dependency and implement versioned IndexedDB-backed persistence for folders, text resources, binary resources, resource metadata, language IDs, workspace manifests, and schema versioning. Hydrate the workspace on startup, persist all core mutation flows, and make ZIP import/export operate against the persisted workspace state.

Include explicit reset/recovery behaviour for corrupted or incompatible local browser storage. Exclude remote sync, filesystem mirroring, directory handles, session-layout restore, and open-tab restore.

### Phase 3.3 — Command palette and contribution-driven shell commands

Implementation anchors:

- Architecture paragraphs: `ARCH-6.1-P01..P05`, `ARCH-6.7-P01..P07`, `ARCH-6.11-P01..P07`, `ARCH-6.17-P01..P04`, `ARCH-7.7-P01..P04`, `ARCH-7.8-P01..P05`, `ARCH-7.9-P01..P04`.
- pnpm packages: Phase 3.3: No new package install.


Update. Expose existing workspace actions as shell command contributions where applicable, including import/export, selected-folder ZIP export, new folder/resource, rename, delete, and storage reset/recovery actions. Do not add new workspace behaviours solely to populate the palette.

### Phase 3.4 — Shapez.io-style document badges and deterministic resource identity

Implementation anchors:

- Architecture paragraphs: `ARCH-5.7-P04`, `ARCH-6.4-P02`, `ARCH-6.14-P08`, `ARCH-7.3-P05`, `ARCH-7.5-P02`, `ARCH-12.4-P01..P02`.
- pnpm packages: Phase 3.4: No new package install.


Update. Generate and persist stable document badge seeds/assignments from resource identity, path/name, resource kind, and language ID. Preserve badges across reload and ZIP export/import where possible. Repair collisions deterministically after restore, duplication, batch upload, or ZIP import, and expose diagnostics when repair changes a badge.

This phase must not introduce real filesystem identity, remote sync identity, arbitrary user icon assets, or document-type taxonomy expansion.


## Tests and definition of done

Persistence tests, Dexie schema/version tests after Phase 3.2, ZIP import/export tests, path normalization tests, binary resource round-trip tests, workspace manifest tests, command contribution tests after Phase 3.3, and badge identity/collision-repair tests after Phase 3.4.

## Non-goals

Do not import app-shell internals. Do not bypass contribution registries. Do not take dependencies that fail the license gate. Do not make this package responsible for unrelated feature domains.

## Repository and workspace workflow

This package lives inside the main TextForge Git repository as an npm workspace package. It should remain independently buildable and testable, but it should not be managed as a Git submodule. Cross-package changes may be made in one branch by one agent, with commits scoped by package where practical. Package dependencies should use `workspace:*` references, and public integration should happen through contribution manifests or stable exported contracts rather than direct app-shell coupling.

## Phase 3 closure note

The package now exposes an `fflate`-backed archive manifest plus full-workspace and selected-folder ZIP export/import helpers, path normalization, and explicit `error | skip | replace` import conflict handling. Focused `lint` and `test` checks pass for the package, and `corepack pnpm verify` covers the broader workspace wiring.

## Phase 3.2 closure note

The package now ships Dexie as a real runtime dependency and exposes a browser-managed persistence path instead of only a schema placeholder. `openWorkspaceDexieStorage`, `createPersistentWorkspaceService`, `createPersistedWorkspaceService`, and `resetWorkspaceDexieStorage` back the existing workspace model with versioned IndexedDB tables for manifests, folders, text resources, binary resources, and schema metadata.

The in-memory service contract also now carries `getManifest`, `replaceState`, and `setSelectedResourceId`, so startup hydration, selection persistence, ZIP import/export, and explicit storage reset/recovery all operate against the persisted workspace state without pulling tab/session restore forward. Focused package checks now cover Dexie hydration, selection persistence, ID continuity after reload, corrupted-storage detection, and reset recovery.

## Phase 3.3 closure note

The package now exposes its existing shell-facing actions as command contributions instead of leaving them hard-wired in the app shell. The delivered command set covers new folder/resource creation, workspace ZIP import/export, selected-folder ZIP export, rename/delete, and explicit storage reset/retry actions over the existing persisted workspace service without adding new workspace behavior solely to fill the palette.
